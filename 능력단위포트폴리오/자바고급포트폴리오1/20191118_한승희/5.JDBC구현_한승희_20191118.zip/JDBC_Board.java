//  시퀀스이름.nextVal
/*
create table jdbc_board(
    board_no number not null,  -- 번호(자동증가)
    board_title varchar2(100) not null, -- 제목
    board_writer varchar2(50) not null, -- 작성자
    board_date date not null,   -- 작성날짜
    board_content clob,     -- 내용
    constraint pk_jdbc_board primary key (board_no)
);
	create sequence board_seq
    start with 1   -- 시작번호
    increment by 1; -- 증가값
 */
package report;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Scanner;

import kr.or.ddit.util.DBUtil3;

public class JDBC_Board {
	static Connection conn = DBUtil3.getConnection();
	SimpleDateFormat format = new SimpleDateFormat("yy/MM/dd");
	
	public static void main(String[] args) {
		JDBC_Board board = new JDBC_Board();
		board.start();
		if(conn!=null) try {conn.close();} catch (SQLException e) {};
	}
	
	private Scanner scan = new Scanner(System.in); 
	//전체 목록 출력, 새 글 작성, 수정, 삭제, 검색 
	public void displayMenu(){
		System.out.println();
		System.out.println("----------------------");
		System.out.println("  === 작 업 선 택 ===");
		System.out.println("  1. 전체 목록 출력");
		System.out.println("  2. 새 글 작성");
		System.out.println("  3. 글 수정");
		System.out.println("  4. 글 삭제");
		System.out.println("  5. 검색");
		System.out.println("  -1. 종료");
		System.out.println("----------------------");
		System.out.print("원하는 작업 선택 >> ");
	}
	
	/**
	 * 프로그램 시작메서드
	 */
	public void start(){
		int choice;
		do{
			displayMenu(); //메뉴 출력
			choice = Integer.parseInt(scan.nextLine()); // 메뉴번호 입력받기
			switch(choice){
				case 1 :  // 전체 목록 출력
					viewAll();
					break;
				case 2 :  // 새 글 작성
					writeList();
					break;
				case 3 :  // 글 수정
					updateList();
					break;
				case 4 :  // 글 삭제
					deleteList();
					break;
				case 5 :  // 검색
					searchList();
					break;
				case -1 :
					System.out.println("작업을 마칩니다.");
					break;
				default :
					System.out.println("번호를 잘못 입력했습니다. 다시입력하세요");
			}
		}while(choice!=-1);
	}
	
	//전체 목록 출력
	private void viewAll()
	{
		Statement stmt = null;
		ResultSet rs = null;
		try {
			stmt = conn.createStatement();
			
			String sql = "SELECT * FROM jdbc_board";
			
			rs = stmt.executeQuery(sql); 
			//board_no board_title board_writer board_date board_content
			System.out.println("\n========================================");
			System.out.println("번호\t제목\t작성자\t작성날짜\t내용");
			
			while(rs.next())
			{
				System.out.println(rs.getInt("board_no")+"\t"+rs.getString("board_title")+"\t"+rs.getString("board_writer")
					+"\t"+format.format(rs.getDate("board_date"))+"\t"+rs.getString("board_content"));
			}
			
			System.out.println("========================================\n");
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if(rs!=null) try {rs.close();} catch (SQLException e) {};
			if(stmt!=null) try {stmt.close();} catch (SQLException e) {};
		}
	}
	
	//새 글 작성
	private void writeList()
	{
		PreparedStatement pstmt = null;
		String title = null, writer = null, content = null;
		
		System.out.println("\n새 글을 작성합니다.");
		System.out.print("글 제목을 입력해주세요 >> ");
		title = scan.nextLine();
		System.out.print("작성자를 입력해주세요 >> ");
		writer = scan.nextLine();
		System.out.print("글 내용을 입력해주세요 >> ");
		content = scan.nextLine();
		
		try {
			//board_no board_title board_writer board_date board_content
			String sql = "INSERT INTO jdbc_board (board_no, board title, board_writer, board_date, board_content)"
					+ " VALUES (board_seq, ?, ?, sysdate, ?)";
			
			pstmt = conn.prepareStatement(sql);
			
			pstmt.setString(1, title);
			pstmt.setString(2, writer);
			pstmt.setString(3, content);
			
			if(pstmt.executeUpdate()>0)
			{
				System.out.println("\n새 글이 작성되었습니다.");
			}
			else
			{
				System.out.println("\n오류가 발생하여 글 작성이 취소되었습니다.");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if(pstmt!=null) try {pstmt.close();} catch (SQLException e) {};
		}
	}
	
	//글 수정
	private void updateList()
	{
		PreparedStatement pstmt1 = null;
		PreparedStatement pstmt2 = null;
		ResultSet rs = null;
		int number;
		String title=null, writer=null, content=null;
		
		System.out.print("수정할 글 번호를 입력해주세요 >> ");
		number = Integer.parseInt(scan.nextLine());
		
		try {
			//board_no board_title board_writer board_date board_content
			String sql1 = "SELECT COUNT(*) cnt FROM jdbc_board WHERE board_no = ?";
			String sql2 = "UPDATE jdbc_board SET board_title = ?, board_writer = ?, board_date = sysdate,"
					+ " board_content = ? WHERE board_no = ?";
			
			pstmt1 = conn.prepareStatement(sql1);
			pstmt2 = conn.prepareStatement(sql2);
			
			pstmt1.setInt(1, number);
			rs = pstmt1.executeQuery(sql1);
			
			rs.next();
			if(rs.getInt("cnt")==0)
			{
				System.out.println("지금 입력하신 번호는 없는 번호입니다.");
			}
			else
			{
				System.out.print("수정할 제목을 입력해주세요 >> ");
				title = scan.nextLine();
				System.out.print("수정할 작성자를 입력해주세요 >> ");
				writer = scan.nextLine();
				System.out.print("수정할 내용을 입력해주세요 >> ");
				content = scan.nextLine();
				
				pstmt2.setString(1, title);
				pstmt2.setString(2, writer);
				pstmt2.setString(3, content);
				pstmt2.setInt(4, number);
				
				if(pstmt2.executeUpdate()>0)
				{
					System.out.println("\n"+ number +"번째 글이 수정되었습니다.");
				}
				else
				{
					System.out.println("\n오류가 발생하여 글 수정이 취소되었습니다.");
				}
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if(rs!=null) try {rs.close();} catch (SQLException e) {};
			if(pstmt1!=null) try {pstmt1.close();} catch (SQLException e) {};
			if(pstmt2!=null) try {pstmt2.close();} catch (SQLException e) {};
		}
	}
	
	//글 삭제
	private void deleteList()
	{
		PreparedStatement pstmt1 = null;
		PreparedStatement pstmt2 = null;
		ResultSet rs = null;
		int number;
		
		System.out.print("삭제할 글 번호를 입력해주세요 >> ");
		number = Integer.parseInt(scan.nextLine());
		
		try {
			//board_no board_title board_writer board_date board_content
			String sql1 = "SELECT COUNT(*) cnt FROM jdbc_board WHERE board_no = ?";
			String sql2 = "DELETE jdbc_board WHERE board_no = ?";
			
			pstmt1 = conn.prepareStatement(sql1);
			pstmt2 = conn.prepareStatement(sql2);
			
			pstmt1.setInt(1, number);
			rs = pstmt1.executeQuery(sql1);
			
			rs.next();
			if(rs.getInt("cnt")==0)
			{
				System.out.println("지금 입력하신 번호는 없는 번호입니다.");
			}
			else
			{
				pstmt2.setInt(1, number);
				
				if(pstmt2.executeUpdate()>0)
				{
					System.out.println("\n"+ number +"번째 글이 삭제되었습니다.");
				}
				else
				{
					System.out.println("\n오류가 발생하여 글 삭제가 취소되었습니다.");
				}
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if(rs!=null) try {rs.close();} catch (SQLException e) {};
			if(pstmt1!=null) try {pstmt1.close();} catch (SQLException e) {};
			if(pstmt2!=null) try {pstmt2.close();} catch (SQLException e) {};
		}
	}
	
	//글 검색
	private void searchList()
	{
		PreparedStatement pstmt1 = null;
		PreparedStatement pstmt2 = null;
		ResultSet rs1 = null;
		ResultSet rs2 = null;
		
		int number;
		
		System.out.print("검색할 글 번호를 입력해주세요 >> ");
		number = Integer.parseInt(scan.nextLine());
		
		try {
			//board_no board_title board_writer board_date board_content
			String sql1 = "SELECT COUNT(*) cnt FROM jdbc_board WHERE board_no = ?";
			String sql2 = "SELECT * FROM jdbc_board WHERE board_no = ?";
			
			pstmt1 = conn.prepareStatement(sql1);
			pstmt2 = conn.prepareStatement(sql2);
			
			pstmt1.setInt(1, number);
			rs1 = pstmt1.executeQuery(sql1);
			
			rs1.next();
			if(rs1.getInt("cnt")==0)
			{
				System.out.println("지금 입력하신 번호는 없는 번호입니다.");
			}
			else
			{
				pstmt2.setInt(1, number);
				
				rs2 = pstmt2.executeQuery(sql2);
				
				rs2.next();
				
				System.out.println("\n"+ number +"번째 글을 검색합니다.");
				System.out.println("번호 : " + rs2.getInt("board_no"));
				System.out.println("제목 : " + rs2.getString("board_title"));
				System.out.println("작성자 : " + rs2.getString("board_writer"));
				System.out.println("날짜 : " + format.format(rs2.getDate("board_date")));
				System.out.println("내용 : " + rs2.getString("board_content") + "\n");
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if(rs1!=null) try {rs1.close();} catch (SQLException e) {};
			if(rs2!=null) try {rs2.close();} catch (SQLException e) {};
			if(pstmt1!=null) try {pstmt1.close();} catch (SQLException e) {};
			if(pstmt2!=null) try {pstmt2.close();} catch (SQLException e) {};
		}
	}
}
