package kr_or_ddit_service;

import java.util.List;

import kr_or_ddit_dao.IJdbcDao;
import kr_or_ddit_dao.JdbcDaoImple;
import kr_or_ddit_vo.JdbcVO;

public class JdbcServiceImpl implements IJdbcService {

	
	//사용할 DAO의 객체 변수 선언
	
	private IJdbcDao JdbcDao;
	
	public JdbcServiceImpl() {
		JdbcDao = new JdbcDaoImple();
	}
	
	
	
	@Override
	public int insertBoard(JdbcVO jv) {
		
		return JdbcDao.insertBoard(jv);
	}

	@Override
	public int deleteBoard(String boardNo) {
		
		return JdbcDao.deleteBoard(boardNo);
	}

	@Override
	public boolean getBoard(String boardNo) {
		
		return JdbcDao.getBoard(boardNo);
	}

	@Override
	public int updateBoard(JdbcVO jv) {
		
		return JdbcDao.updateBoard(jv);
	}

	@Override
	public List<JdbcVO> getBoardList() {
		
		return JdbcDao.getBoardList();
	}

}
