package kr_or_ddit_dao;

import java.util.List;

import kr_or_ddit_vo.JdbcVO;

public interface IJdbcDao {

	public int insertBoard(JdbcVO jv);
	
	
	public int deleteBoard(String boardNo);
	
	
	public boolean getBoard(String boardNo);
	
	
	public int updateBoard(JdbcVO jv);
	
	public List<JdbcVO> getBoardList();
	

	
	
}
