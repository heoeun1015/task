package kr_or_ddit_dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;

import kr_or_ddit_vo.JdbcVO;

public class JdbcDaoImple implements IJdbcDao {

	private Connection conn;
	private Statement stmt;
	private PreparedStatement pstmt;
	private ResultSet rs;
	
	// 자원반납
	private void disConnect() {
		if(rs!=null)try{ rs.close(); }catch(SQLException e){}
		if(pstmt!=null)try{ pstmt.close(); }catch(SQLException e){}
		if(stmt!=null)try{ stmt.close(); }catch(SQLException e){}
		if(conn!=null)try{ conn.close(); }catch(SQLException e){}
	}
	
	
	@Override
	public int insertBoard(JdbcVO jv) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int deleteBoard(String boardNo) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public boolean getBoard(String boardNo) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int updateBoard(JdbcVO jv) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public List<JdbcVO> getBoardList() {
		// TODO Auto-generated method stub
		return null;
	}

}
