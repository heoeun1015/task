package kr.or.ddit.board.service;

import java.util.List;

import kr.or.ddit.board.dao.BoardDaoImpl;
import kr.or.ddit.board.vo.BoardVO;

public class BoardServiceImpl implements IBoardService {
	private static BoardServiceImpl service;

	// 사용할 DAO의 객체변수를 선언한다.
	private BoardDaoImpl boarddao;

	private BoardServiceImpl (){
		boarddao = BoardDaoImpl.getInstance();
	}

	public static BoardServiceImpl getInstance() {
		if (service == null) {
			service = new BoardServiceImpl();
		}

		return service;
	}

	@Override
	public List<BoardVO> displayAll() {
		return boarddao.displayAll();
	}

	@Override
	public int newWrite(BoardVO board) {
		return boarddao.newWrite(board);
	}

	@Override
	public int modifyWrite(BoardVO board) {
		return boarddao.modifyWrite(board);
	}

	@Override
	public int deleteWrite(int boardNum) {
		return boarddao.deleteWrite(boardNum);
	}

	@Override
	public List<BoardVO> search(BoardVO board) {
		// TODO Auto-generated method stub
		return boarddao.search(board);
	}

}
