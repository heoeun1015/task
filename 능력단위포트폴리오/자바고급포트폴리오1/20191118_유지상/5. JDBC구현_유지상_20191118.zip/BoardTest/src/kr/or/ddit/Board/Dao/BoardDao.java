package kr.or.ddit.Board.Dao;

import java.util.List;
import kr.or.ddit.Board.vo.BoardVO;

public interface BoardDao {


	public List<BoardVO> totalBoard();
	
	public int writePost(BoardVO bv);
	
	public int updatePost(BoardVO bv);
	
	public int deletePost(int boardNum);
	
	public List<BoardVO> searchPost(int boardNum);
	
	public boolean checkboardNumber(int boardNum);

	
}
