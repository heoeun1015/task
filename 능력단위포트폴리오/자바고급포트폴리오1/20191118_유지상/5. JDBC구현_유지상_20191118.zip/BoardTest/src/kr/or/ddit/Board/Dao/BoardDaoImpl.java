package kr.or.ddit.Board.Dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import kr.or.ddit.Board.vo.BoardVO;
import kr.or.ddit.util.DBUtil;


public class BoardDaoImpl implements BoardDao {
	
	//싱글톤 패턴
	private static BoardDaoImpl instance;
	private BoardDaoImpl() {};
	
	public static BoardDaoImpl getInstance() {
		if(instance == null) {
			instance = new BoardDaoImpl();
		}
		return instance;
	}
	
	// ================================================================

	
	//DB에 연결하기 위한 작업
	private Connection conn;
	private PreparedStatement pstmt;
	private ResultSet rs;
	
	private void disConnect() {	//자원 반납
		if(pstmt!=null){ try {pstmt.close();} catch(SQLException e){} }
		if(conn!=null){ try {conn.close();} catch(SQLException e){} }
		if(rs!=null){ try {rs.close();} catch(SQLException e){} }
	}
	
	// ================================================================
	
	
	
	@Override
	public List<BoardVO> totalBoard() {
		List<BoardVO> boardList = new ArrayList<BoardVO>();
		
		try {
			conn = DBUtil.getConnection();
			
			String sql = "SELECT * FROM jdbc_board ORDER BY board_no";
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();
			
			while(rs.next()) {
				BoardVO bv = new BoardVO();
					bv.setBoardNum(rs.getInt("board_no"));
					bv.setBoardTitle(rs.getString("board_title"));
					bv.setBoardWriter(rs.getString("board_writer"));
					bv.setBoardDate(rs.getDate("board_date"));
				boardList.add(bv);
			}
		} catch(SQLException e) {
			e.printStackTrace();
		} finally {
			disConnect();
		}
		return boardList;
	}

	
	
	
	@Override
	public int writePost(BoardVO bv) {
		int cnt = 0;
		
		try {
			conn = DBUtil.getConnection();
			String sql = "INSERT INTO jdbc_board"
						+" VALUES (board_seq.NEXTVAL, ?, ?, ?, ?)";
			
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, bv.getBoardTitle());
			pstmt.setString(2, bv.getBoardWriter());
			pstmt.setDate(3, bv.getBoardDate());
			pstmt.setString(4, bv.getBoardContent());
			cnt = pstmt.executeUpdate();
			
		}catch(SQLException e){
			e.printStackTrace();
		}finally { disConnect(); }
		
		return cnt;
	}
	
	
	
	
	
	@Override
	public int updatePost(BoardVO bv) {
		int cnt = 0;
		
		try {
			conn = DBUtil.getConnection();
			
			String sql = "UPDATE jdbc_board SET board_title = ?,"
											 +" board_writer = ?,"
											 +" board_content = ?"
										 +" WHERE board_no = ?";

			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, bv.getBoardTitle());
			pstmt.setString(2, bv.getBoardWriter());
			pstmt.setString(3, bv.getBoardContent());
			pstmt.setInt(4, bv.getBoardNum());
			
			cnt = pstmt.executeUpdate();
			
		}catch(SQLException e) {
			e.printStackTrace();
		}finally { disConnect(); }
		
		return cnt;
	}

	
	
	
	@Override
	public int deletePost(int boardNum) {
		int cnt = 0;
		try {
			conn = DBUtil.getConnection();
			
			String sql = "DELETE FROM jdbc_board WHERE board_no = ?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, boardNum);
			cnt = pstmt.executeUpdate();
			
		}catch (SQLException e) {
			e.printStackTrace();
		}finally { disConnect(); }
		
		return cnt;
	}

	
	
	
	@Override
	public List<BoardVO> searchPost(int boardNum) {
		
		List<BoardVO> boardList = new ArrayList<>();
		
		try {
			conn = DBUtil.getConnection();
			String sql = "SELECT * FROM jdbc_board WHERE board_no = ?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, boardNum);
			
			rs = pstmt.executeQuery();
			
			if(rs.next()) {
				BoardVO bv = new BoardVO();
					bv.setBoardNum(boardNum);
					bv.setBoardTitle(rs.getString("board_title"));
					bv.setBoardWriter(rs.getString("board_writer"));
					bv.setBoardDate(rs.getDate("board_date"));
					bv.setBoardContent(rs.getString("board_content"));
				boardList.add(bv);
			}
			
		}catch(SQLException e) {
			e.printStackTrace();
		}finally { disConnect(); }

		return boardList;
	}

	
	
	
	@Override
	public boolean checkboardNumber(int boardNum) {
		conn = DBUtil.getConnection();
		
		String sql = "SELECT COUNT(board_no) cnt"
				   +" FROM jdbc_board"
				   +" WHERE board_no = ?";
		
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, boardNum);
			rs = pstmt.executeQuery();
			
			if(rs.next()) {
				int count = rs.getInt("cnt");
				if(count == 0) {
					return false;
				}else {
					return true;
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return false;
	}


}
