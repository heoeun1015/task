package kr.or.ddit.Board.Service;

import java.util.List;

import kr.or.ddit.Board.Dao.BoardDao;
import kr.or.ddit.Board.Dao.BoardDaoImpl;
import kr.or.ddit.Board.vo.BoardVO;

public class BoardServiceImpl implements BoardService {

	//싱글톤패턴
	private static BoardServiceImpl instance;
	private BoardServiceImpl() {};
	public static BoardServiceImpl getInstance() {
		if(instance == null) {
			instance = new BoardServiceImpl();
		}
		return instance;
	}
	//========================================================
	
	BoardDao boardDao = BoardDaoImpl.getInstance();

	
	@Override
	public List<BoardVO> totalBoard() {
		return boardDao.totalBoard();
	}

	@Override
	public int writePost(BoardVO bv) {
		return boardDao.writePost(bv);
	}

	@Override
	public int updatePost(BoardVO bv) {
		return boardDao.updatePost(bv);
	}

	@Override
	public int deletePost(int boardNum) {
		return boardDao.deletePost(boardNum);
	}

	@Override
	public List<BoardVO> searchPost(int boardNum) {
		return boardDao.searchPost(boardNum);
	}

	@Override
	public boolean checkboardNumber(int boardNum) {
		return boardDao.checkboardNumber(boardNum);
	}

}
