package MB_service;

import java.util.List;

import MB_dao.IMessageBoardDao;
import MB_dao.MessageBoardImpl;
import MB_vo.MessageBoardVO;

public class MessageBoardServiceImpl implements IMessageService {
	
	private IMessageBoardDao mbDao;
	
	public MessageBoardServiceImpl() {
		mbDao = MessageBoardImpl.getInstance();
	}

	@Override
	public int insert(MessageBoardVO mb) {
		return mbDao.insert(mb);
	}

	@Override
	public List<MessageBoardVO> getSelectList() {
		return mbDao.getSelectList();
	}

	@Override
	public int delete(String board_no) {
		return mbDao.delete(board_no);
	}

	@Override
	public int update(MessageBoardVO mb) {
		return mbDao.update(mb);
	}

	@Override
	public List<MessageBoardVO> getSearchList(MessageBoardVO mb) {
		return mbDao.getSearchList(mb);
	}

}
