package MB_service;

import java.util.List;

import MB_vo.MessageBoardVO;

public interface IMessageService {

	public int insert(MessageBoardVO mb);

	public List<MessageBoardVO> getSelectList();

	public int delete(String board_no);

	public int update(MessageBoardVO mb);

	public List<MessageBoardVO> getSearchList(MessageBoardVO mb);

}
