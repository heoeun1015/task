package MB_dao;

import java.io.IOException;
import java.io.Reader;
import java.nio.charset.Charset;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.ibatis.common.resources.Resources;
import com.ibatis.sqlmap.client.SqlMapClient;
import com.ibatis.sqlmap.client.SqlMapClientBuilder;

import MB_vo.MessageBoardVO;

public class MessageBoardImpl implements IMessageBoardDao {

	private SqlMapClient smc;
	
	private static MessageBoardImpl dao;
	
	private MessageBoardImpl() {
		Reader rd;
		try {
		// 1-1. xml문서 읽어오기
					Charset charset = Charset.forName("UTF-8");	// 설정파일 인코딩
					Resources.setCharset(charset);
					
					rd = Resources.getResourceAsReader("sqlMapConfig.xml");
					
					// 1-2. 위에서 읽어오 Reader객체를 이용하여 실제 작업을 진행할 객체 생성
					smc = SqlMapClientBuilder.buildSqlMapClient(rd);
					rd.close();
		}catch (IOException e) {
			System.out.println("SqlMapClient객체 생성 실패 !!!");
			e.printStackTrace();
		}
	}
	
	public static IMessageBoardDao getInstance() {
		if(dao == null) {
			dao = new MessageBoardImpl();
		}
		
		return dao;
	}	

	@Override
	public int insert(MessageBoardVO mb) {
		int cnt = 0;

		try {
			Object obj = smc.insert("MessageBoard.insert", mb);
			if(obj == null) {
				cnt = 1;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return cnt;
	}

	@Override
	public int delete(String board_no) {
		int cnt = 0;

		try {
			cnt = smc.delete("MessageBoard.delete", board_no);
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return cnt;
	}

	@Override
	public int update(MessageBoardVO mb) {
		int cnt = 0;

		try {
			cnt = smc.update("MessageBoard.update", mb);
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return cnt;
	}

	@Override
	public List<MessageBoardVO> getSelectList() {

		List<MessageBoardVO> mbList = new ArrayList<>();
		
		try {
			mbList = smc.queryForList("MessageBoard.getSelectList");
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return mbList;
	}

	@Override
	public List<MessageBoardVO> getSearchList(MessageBoardVO mb) {

		List<MessageBoardVO> mbList = new ArrayList<>();
		try {
			mbList = smc.queryForList("MessageBoard.getSelectList", mb);
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return mbList;
	}

}
