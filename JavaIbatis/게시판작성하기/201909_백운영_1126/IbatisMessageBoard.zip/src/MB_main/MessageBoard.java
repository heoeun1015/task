package MB_main;

import java.util.List;
import java.util.Scanner;

import MB_service.IMessageService;
import MB_service.MessageBoardServiceImpl;
import MB_vo.MessageBoardVO;

public class MessageBoard {
	private IMessageService service;

	private Scanner sc = new Scanner(System.in);

	public MessageBoard() {
		service = new MessageBoardServiceImpl();
		sc = new Scanner(System.in);
	}

	public void menu() {
		System.out.println("-------------------------------------------------------\r" + "\t\t     게   시   판\r"
				+ "-------------------------------------------------------\r" + "1. 게시물 등록       2. 게시물 삭제  3. 게시물 수정\r"
				+ "4. 전체 게시물 조회  5. 게시물 검색  6. 프로그램 종료\r" + "-------------------------------------------------------");
	}

	public void start() {

		int choice;

		do {
			menu();
			choice = sc.nextInt();
			switch (choice) {
			case 1:
				insert();
				break;
			case 2:
				delete();
				break;
			case 3:
				update();
				break;
			case 4:
				select();
				break;
			case 5:
				search();
				break;
			case 6:
				System.out.println("프로그램을 종료합니다.");
				return;
			default:
				System.out.println("잘못 입력하셨습니다. 다시 입력해주세요.");
			}
		} while (choice != 6);
	}

	public static void main(String[] args) {
		MessageBoard mbObj = new MessageBoard();
		mbObj.start();
	}

	private void insert() {

		System.out.print("게시물 제목을 입력하세요 > ");
		String board_title = sc.next();

		System.out.print("작성자를 입력하세요 > ");
		String board_writer = sc.next();

		System.out.print("내용을 입력해주세요 > ");
		String board_content = sc.next();

		MessageBoardVO mb = new MessageBoardVO();
		mb.setBoard_title(board_title);
		mb.setBoard_writer(board_writer);
		mb.setBoard_content(board_content);

		int cnt = service.insert(mb);

		if (cnt > 0) {
			System.out.println("게시물 등록이 완료되었습니다.");
		} else {
			System.out.println("게시물 등록이 실패했습니다.");
		}

	}

	private void delete() {
		System.out.println();

		System.out.print("삭제하려는 게시물의 번호를 입력하세요 > ");
		String board_no = sc.next();

		int cnt = service.delete(board_no);

		if (cnt > 0) {
			System.out.println("게시물이 삭제되었습니다.");
		} else {
			System.out.println("게시물 삭제에 실패했습니다.");
		}

	}

	private void update() {
		System.out.println();

		System.out.print("수정할 게시물 번호를 선택해주세요 > ");
		String board_no = sc.next();

		System.out.print("게시물 제목을 입력하세요 > ");
		String board_title = sc.next();

		System.out.print("내용을 입력해주세요 > ");
		String board_content = sc.next();

		MessageBoardVO mb = new MessageBoardVO();
		mb.setBoard_title(board_title);
		mb.setBoard_content(board_content);
		mb.setBoard_no(board_no);

		int cnt = service.update(mb);

		if (cnt > 0) {
			System.out.println("게시물 수정 성공 !");
		} else {
			System.out.println("게시물 수정 실패 !");
		}
	}

	private void select() {
		System.out.println("┌----------------------- 게시물 ----------------------┐");

		List<MessageBoardVO> mbList = service.getSelectList();

		for (MessageBoardVO mb : mbList) {
			System.out.println("   No\t제목\t\t작성자  작성일");
			System.out.println("   " + mb.getBoard_no() + "\t" + mb.getBoard_title() + "\t\t" + mb.getBoard_writer()
					+ "\t" + mb.getBoard_date());
			System.out.println("\t\t\t내용");
			System.out.println("   " + mb.getBoard_content());
		}
		System.out.println("└-----------------------------------------------------┘");

	}

	private void search() {
		sc.nextLine();
		System.out.println();
		System.out.print("검색할 게시물 번호를 입력하세요 > ");
		String board_no = sc.nextLine().trim();
		
		System.out.print("검색할 제목을 입력하세요 > ");
		String board_title = sc.nextLine().trim();
		
		System.out.print("검색할 작성자를 입력하세요 > ");
		String board_writer = sc.nextLine().trim();
		
		System.out.print("검색할 작성일자를 입력하세요 > ");
		String board_date = sc.nextLine().trim();
		
		System.out.print("검색할 내용을 입력하세요 > ");
		String board_content = sc.nextLine().trim();

		MessageBoardVO mb = new MessageBoardVO();
		mb.setBoard_no(board_no);
		mb.setBoard_title(board_title);
		mb.setBoard_writer(board_writer);
		mb.setBoard_date(board_date);
		mb.setBoard_content(board_content);
		
		System.out.println("┌----------------------- 게시물 ----------------------┐");

		List<MessageBoardVO> mbList = service.getSearchList(mb);

		for (MessageBoardVO mb2 : mbList) {
			System.out.println("   No\t제목\t\t작성자  작성일");
			System.out.println("   " + mb2.getBoard_no() + "\t" + mb2.getBoard_title() + "\t\t" + mb2.getBoard_writer()
					+ "\t" + mb2.getBoard_date());
			System.out.println("\t\t\t내용");
			System.out.println("   " + mb2.getBoard_content());
		}
		System.out.println("└-----------------------------------------------------┘");

	}
}
