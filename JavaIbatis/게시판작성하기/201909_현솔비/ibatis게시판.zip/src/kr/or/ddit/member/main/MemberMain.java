package kr.or.ddit.member.main;

import java.util.List;
import java.util.Scanner;

import kr.or.ddit.member.service.IMemberService;
import kr.or.ddit.member.service.MemberServiceImple;
import kr.or.ddit.member.vo.MemberVO;
/*
	회원정보를 관리하는 프로그램을 작성하는데 
	아래의 메뉴를 모두 구현하시오. (CRUD기능 구현하기)
	(DB의 MYMEMBER테이블을 이용하여 작업한다.)
	
	* 자료 삭제는 회원ID를 입력 받아서 삭제한다.
	
	예시메뉴)
	----------------------
		== 작업 선택 ==
		1. 자료 입력			---> insert
		2. 자료 삭제			---> delete
		3. 자료 수정			---> update
		4. 전체 자료 출력	---> select
		5. 작업 끝.
	----------------------
	 
	   
// 회원관리 프로그램 테이블 생성 스크립트 
create table mymember(
    mem_id varchar2(8) not null,  -- 회원ID
    mem_name varchar2(100) not null, -- 이름
    mem_tel varchar2(50) not null, -- 전화번호
    mem_addr varchar2(128)    -- 주소
);

*/
public class MemberMain {
	
	//Service객체 변수를 선언한다.
	private IMemberService service;
	
	private Scanner scan = new Scanner(System.in); 
	
	public MemberMain() {
		service = MemberServiceImple.getInstance();
	}
	
	/**
	 * 메뉴를 출력하는 메서드
	 */
	public void displayMenu(){
		System.out.println();
		System.out.println("----------------------");
		System.out.println("  === 작 업 선 택 ===");
		System.out.println("  1. 전체 목록 출력");
		System.out.println("  2. 새글 작성");
		System.out.println("  3. 수정");
		System.out.println("  4. 삭제");
		System.out.println("  5. 검색");
		System.out.println("  0. 작업 끝.");
		System.out.println("----------------------");
		System.out.print("원하는 작업 선택 >> ");
	}
	
	/**
	 * 프로그램 시작메서드
	 */
	public void start(){
		int choice;
		do{
			displayMenu(); //메뉴 출력
			choice = scan.nextInt(); // 메뉴번호 입력받기
			switch(choice){
				case 1 :  // 전체 목록 출력
					displayMemberAll();
					break;
				case 2 :  // 새글 작성
					writeMember();
					break;
				case 3 :  // 수정
					updateMember();
					break;
				case 4 :  // 삭제
					deleteMember();
					break;
				case 5 :  // 검색
					searchMember();
					break;
				case 0 :  // 작업 끝
					System.out.println("작업을 마칩니다.");
					break;
				default :
					System.out.println("번호를 잘못 입력했습니다. 다시입력하세요");
			}
		}while(choice!=0);
	}
	
	//회원정보를 검색하는 메서드
	private void searchMember() {
		//검색할 회원ID,회원이름, 전화번호, 주소 등을 입력하면
		//입력한 정보만 사용하여 검색하는 기능을 구현하시오.
		//주소는 입력한 값이 포함만 되어도 검색되도록 구현한다.
		//입력을 하지 않을 자료는 엔터키로 다음 입력으로 넘어간다.
		scan.nextLine();
		System.out.println();
		System.out.println("검색할 게시글 정보를 입력하세요.");
		System.out.print("번호 >> ");
		String memNo = scan.nextLine().trim();
		
		System.out.print("제목 >> ");
		String memTitle = scan.nextLine().trim();
		
		System.out.print("작성자 >> ");
		String memWriter = scan.nextLine().trim();
		
		System.out.print("내용 >> ");
		String memContent = scan.nextLine().trim();
		
		MemberVO mv = new MemberVO();
		mv.setBOARD_NO(memNo);
		mv.setBOARD_TITLE(memTitle);
		mv.setBOARD_WRITER(memWriter);
		mv.setBOARD_CONTENT(memContent);
		
		//입력한 정보로 검색한 내용을 출력하는 부분
		List<MemberVO> memList = service.getSearchMember(mv);
		
		System.out.println();
		System.out.println("-----------------------------------------------");
		System.out.println(" 번  호\t제  목\t작성자\t작성날짜\t\t\t내  용");
		
		if(memList == null || memList.size()==0) {
			System.out.println("검색할 자료가 하나도 없습니다.");
		}else {
			for(MemberVO mv2 : memList) {
				System.out.println(mv.getBOARD_NO() + "\t" 
						+ mv2.getBOARD_TITLE() + "\t" 
						+ mv2.getBOARD_WRITER() +"\t"
						+ mv2.getBOARD_DATE()+"\t"
						+ mv2.getBOARD_CONTENT());
			}
		}
		
		System.out.println("-----------------------------------------------");
		System.out.println("출력작업 끝...");
	}

	//글을 삭제하는 메서드
	private void deleteMember() {
		System.out.println();
		System.out.print("삭제할 글번호 >>");
		String memNo = scan.next();
	
		int cnt = service.deleteMember(memNo);
		
		if(cnt > 0) {
			System.out.println(memNo + "번 게시글 삭제 성공...");
		}else {
			System.out.println(memNo + "번 게시글 삭제 실패~!");
		}
	}

	//글을 수정하는 메서드
	private void updateMember() {
		System.out.println();
		String memNo = "";
		boolean chk = true;
		
		do {
			System.out.print("수정 할 게시글의 번호를 입력하세요> ");
			memNo= scan.next();
			
			chk = service.getNum(memNo);
			if(chk == false) {
				
				System.out.println("수정할 게시글이 없습니다. 다시 입력하세요.");
			}
			
		}while(chk==false);
		
		System.out.print("작성자를 입력하세요 >> ");
		String memWriter = scan.next();
		
		
		System.out.print("제목을 입력하세요 >> ");
		String memTitle = scan.next();
		
		
		scan.nextLine();
		System.out.print("내용을 입력하세요 >> ");
		String memContent = scan.nextLine();
		
		MemberVO mv = new MemberVO();
		mv.setBOARD_NO(memNo);
		mv.setBOARD_TITLE(memTitle);
		mv.setBOARD_WRITER(memWriter);
		mv.setBOARD_CONTENT(memContent);
		
		int cnt = service.updateMember(mv);
		
		if(cnt > 0) {
			System.out.println("글을 수정했습니다.");
		}else {
			System.out.println("수정 실패~!");
		}
			
	}

	//전체회원을 출력하는 메서드
	private void displayMemberAll() {
		System.out.println();
		System.out.println("--------------------------------------------------------");
		System.out.println(" 번  호\t제  목\t작성자\t작성날짜\t\t\t내  용");
		
		List<MemberVO> memList = service.getAllMemberList();
		
		for(MemberVO mv : memList) {
		System.out.println(mv.getBOARD_NO() + "\t" 
						+ mv.getBOARD_TITLE() + "\t" 
						+ mv.getBOARD_WRITER() +"\t"
						+ mv.getBOARD_DATE()+"\t"
						+ mv.getBOARD_CONTENT());
		}
		
		System.out.println("--------------------------------------------------------");
		System.out.println("출력작업 끝...");
		
	}

	//새 글을 작성하는 메서드
	private void writeMember() {
		
		System.out.print("제목을 입력하세요>> ");
		String memTitle = scan.next();
		
		System.out.print("작성자 이름을 입력하세요>> ");
		String memWriter = scan.next();
		
		scan.nextLine();	//입력버퍼 비우기
		
		System.out.print("내용을 입력하세요>> ");
		String memContent = scan.nextLine();
		
		MemberVO mv = new MemberVO();
		mv.setBOARD_TITLE(memTitle);
		mv.setBOARD_WRITER(memWriter);
		mv.setBOARD_CONTENT(memContent);
		
		int cnt = service.writeMember(mv);
		
		if(cnt>0) {
			System.out.println("게시글 추가 작업 성공");
		}else {
			System.out.println("게시글 추가 작업 실패~");
		}
	}

	public static void main(String[] args) {
		MemberMain memObj = new MemberMain();
		memObj.start();
	}
}