package kr.or.ddit.member.service;

import java.util.List;

import kr.or.ddit.member.dao.IMemberDao;
import kr.or.ddit.member.dao.MemberDaoImpl;
import kr.or.ddit.member.vo.MemberVO;

public class MemberServiceImple implements IMemberService {

	private static MemberServiceImple service;
	
	//사용할 DAO의 객체변수를 선언한다.
	private IMemberDao memDao;
//	private MemberDaoImpl memDao;			//둘 다 가능
	
	public MemberServiceImple() {			//생성자
		
		memDao = MemberDaoImpl.getInstance();
	}
	
	public static MemberServiceImple getInstance() {	//생성자
		if(service == null) {
			service = new MemberServiceImple();
		}
		
		return service;
	}
	
	@Override
	public int writeMember(MemberVO mv) {
		
		return memDao.writeMember(mv);
	}

	@Override
	public boolean getNum(String memNo) {
		
		return memDao.getNum(memNo);
	}
	

	@Override
	public List<MemberVO> getAllMemberList() {
		
		return memDao.getAllMemberList();
	}

	@Override
	public int updateMember(MemberVO mv) {
		
		return memDao.updateMember(mv);
	}

	@Override
	public int deleteMember(String memNo) {

		return memDao.deleteMember(memNo);
	}

	@Override
	public List<MemberVO> getSearchMember(MemberVO mv) {

		return memDao.getSearchMember(mv);
	}
}
