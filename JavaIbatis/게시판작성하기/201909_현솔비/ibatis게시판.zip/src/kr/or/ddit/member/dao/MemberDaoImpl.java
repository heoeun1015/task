package kr.or.ddit.member.dao;

import java.io.IOException;
import java.io.Reader;
import java.nio.charset.Charset;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.ibatis.common.resources.Resources;
import com.ibatis.sqlmap.client.SqlMapClient;
import com.ibatis.sqlmap.client.SqlMapClientBuilder;

import kr.or.ddit.member.vo.MemberVO;
import kr.or.ddit.util.DBUtil;

public class MemberDaoImpl implements IMemberDao {
	
	private SqlMapClient smc;				//SqlMapClient 담을변수
	
	private static IMemberDao dao;			
	
	private MemberDaoImpl() {				//생성자를 private으로 
		Reader rd;
		try {
			
			//SqlMapClient객체 가져오기 ibatis쓰기위해
			//1-1. xml문서 읽어오기
			Charset charset = Charset.forName("UTF-8");	//설정파일인코딩
			Resources.setCharset(charset);
			
			rd = Resources.getResourceAsReader("sqlMapConfig.xml");
			
			//1-2. 위에서 읽어온 Reader객체를 이용하여 실제 작업을 진행할 객체 생성
			smc = SqlMapClientBuilder.buildSqlMapClient(rd);
			
			rd.close();
		
		} catch (IOException e) {
			System.out.println("SqlMapClient객체 생성 실패!");
			e.printStackTrace();
		}
	}
	
	public static IMemberDao getInstance() {
		if(dao == null) {
			dao = new MemberDaoImpl();
		}
		
		return dao;
	}
	
	
	@Override
	public int writeMember(MemberVO mv) {
		int cnt = 0;
		
		try {
			Object obj = smc.insert("member.writeMember", mv);
			if(obj == null) {
				cnt = 1;											//성공하면 null
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return cnt;													//성공:1, 실패:0
	}

	@Override
	public boolean getNum(String memNo) {
		
		boolean chk = false;
		
		int cnt = 0;
		
		try {
			
			cnt = (int) smc.queryForObject("member.getNum", memNo);
			
			if(cnt>0) {
				chk = true;
			}
			
		}catch (SQLException e) {
			e.printStackTrace();
		}
		return chk;
	}

	@Override
	public List<MemberVO> getAllMemberList() {
		
		List<MemberVO> memList = new ArrayList<MemberVO>();
		
		try {
			memList = smc.queryForList("member.getMemberAll");
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return memList;
	}

	@Override
	public int updateMember(MemberVO mv) {
		
		int cnt = 0;
		
		try {
			cnt = smc.update("member.updateMember", mv);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return cnt;
	}

	@Override
	public int deleteMember(String memNo) {
		
		int cnt = 0;
		
		try {
			cnt = smc.delete("member.deleteMember", memNo);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return cnt;
	}

	/**
	 * 검색
	 */
	@Override
	public List<MemberVO> getSearchMember(MemberVO mv) {
		
		List<MemberVO> memList = new ArrayList<>();
		try {
			memList = smc.queryForList("member.getSearchMember", mv);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		
		return memList;
	}
}
