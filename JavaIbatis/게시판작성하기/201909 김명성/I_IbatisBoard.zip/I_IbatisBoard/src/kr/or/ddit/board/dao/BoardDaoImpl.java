package kr.or.ddit.board.dao;

import java.io.IOException;
import java.io.Reader;
import java.nio.charset.Charset;
import java.sql.Connection;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.ibatis.common.resources.Resources;
import com.ibatis.sqlmap.client.SqlMapClient;
import com.ibatis.sqlmap.client.SqlMapClientBuilder;

import kr.or.ddit.board.vo.BoardVO;
import kr.or.ddit.util.DBUtil2;

public class BoardDaoImpl implements IBoardDao {
	private Connection conn;
	private Statement stmt;
	private PreparedStatement pstmt;
	private ResultSet rs;
	
	
	private SqlMapClient smc;
	
	private static IBoardDao dao;
	
	// 생성자
	private BoardDaoImpl() {
		Reader rd;
		try {
			
			Charset charset = Charset.forName("UTF-8");
			Resources.setCharset(charset);
			
			rd = Resources.getResourceAsReader("sqlMapConfig.xml");
			
			smc = SqlMapClientBuilder.buildSqlMapClient(rd);
			rd.close();
		} catch (IOException e) {
			System.out.println("SqlMapClient객체 생성 실패!!");
			e.printStackTrace();
		}
	}
	
	public static IBoardDao getInstance() {
		if(dao == null) {
			dao = new BoardDaoImpl();
		}
		return dao;
	}
	
	/**
	 * 자원반납
	 */
	private void disConnect() {
		// 사용했던 자원 반납
		if(pstmt !=null) try {pstmt.close();}catch(SQLException e) {}
		if(rs!=null) try {rs.close();}catch(SQLException e) {}
		if(stmt!=null) try {stmt.close();}catch(SQLException e) {}
		if(conn!=null) try {conn.close();}catch(SQLException e) {}

	}

	@Override
	public int writePost(BoardVO bv) {
		int cnt = 0;
		try {
			Object obj = smc.insert("board.insertBoard", bv);	
			if(obj == null) {
				cnt = 1;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return cnt;
	}

	@Override
	public List<BoardVO> displayPost() {
		List<BoardVO> boardList = new ArrayList<BoardVO>();

		try {
			boardList = smc.queryForList("board.getBoardAll");
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return boardList;
	}

	@Override
	public int editPost(BoardVO bv) {
		int cnt = 0;
		try {
			cnt = smc.update("board.updateBoard", bv);
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return cnt;
	}

	@Override
	public int deletePost(String board_no) {
		int cnt = 0;
		try {
			cnt = smc.delete("board.deleteBoard", board_no);

		} catch (SQLException e) {
			e.printStackTrace();
		}
		return cnt;
	}

	@Override
	public List<BoardVO> getSearchBoard(BoardVO bv) {
		List<BoardVO> boardList = new ArrayList<>();

		try {
			boardList = smc.queryForList("board.getsearchBoard", bv);
			

		}catch (Exception e) {
			e.printStackTrace();
		}

		return boardList;
	}

}
