package kr.or.ddit.board.service;

import java.util.List;

import kr.or.ddit.board.vo.BoardVO;

public interface IBoardService {
	
	// 게시글 등록
	public int writePost(BoardVO bv);
	//게시글 전체 출력
	public List<BoardVO> displayPost();
	// 게시글 수정
	public int editPost(BoardVO bv);
	// 게시글 삭제
	public int deletePost(String board_no);
	//게시글 조회
	public List<BoardVO> getSearchBoard(BoardVO bv);
}
