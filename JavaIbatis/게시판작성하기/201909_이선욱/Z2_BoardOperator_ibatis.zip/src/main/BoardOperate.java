package main;

import java.util.List;
import java.util.Scanner;

import board.service.BoardServiceImpl;
import board.service.IBoardService;
import board.vo.BoardVO;


public class BoardOperate {

	//Service객체 변수를 선언한다.
	private IBoardService service;
	
	private Scanner scan = new Scanner(System.in); 
	
	public BoardOperate() {
		service = BoardServiceImpl.getInstance();
	}
	
	//메뉴 출력하기
	public void  displayMenu() {
		System.out.println();
		System.out.println("------게시판 운영 시스템------");
		System.out.println();
		System.out.println("  === 게 시 판 관 리 ===");
		System.out.println("  1. 전체 게시글 목록 출력");
		System.out.println("  2. 새 게시글 작성");
		System.out.println("  3. 게시글 수정");
		System.out.println("  4. 게시글 삭제");
		System.out.println("  5. 검색"); 
		System.out.println("  6. 나가기");
		System.out.println("----------------------");
		System.out.print("원하는 번호를 선택해주세요. >> ");
	}
	
	//프로그램 시작 메서드
	public void start(){
		int choice;
		do{
			displayMenu(); //메뉴 출력
			choice = Integer.parseInt(scan.nextLine()); // 메뉴번호 입력받기
			switch(choice){
				case 1 :  // 전체 게시글 목록 출력
					listAllBoard();
					break;
				case 2 :  // 새 게시글 등록
					insertBoard();
					break;
				case 3 :  // 게시글 수정
					updateBoard();
					break;
				case 4 :  // 게시글 삭제
					deleteBoard();
					break;
				case 5 :  // 검색
					search();
					break;
				case 6 :  // 나가기
					System.out.println("게시판 운영 시스템이 종료되었습니다..");
					break;
				default :
					System.out.println("번호를 잘못 입력했습니다. 다시입력하세요");
			}
		}while(choice!=6);
	}
	
	//어떤 항목으로 검색할지 묻는 메서드
	private void search() {
		int input;
		
		do{
			System.out.println();
			System.out.println("==어떤 항목으로 검색하시겠습니까?==");
			System.out.println("1. 제목    2. 작성자    3. 내용    4. 홈으로 돌아가기");
			input = Integer.parseInt(scan.nextLine());
			
			switch(input){
				case 1 :  //제목
					titleSearch();
					break;
				case 2 :  //작성자
					writerSearch();
					break;
				case 3 :  //내용
					contentSearch();
					break;
				case 4 :  // 나가기
					System.out.println("홈으로 돌아갑니다");
					break;
				default :
					System.out.println("번호를 잘못 입력했습니다. 다시입력하세요");
			}
		}while(input !=4);
	}

	//내용으로 검색
	private void contentSearch() {
		System.out.println();
		System.out.println("검색할 내용을 입력하세요.");
		String content = scan.nextLine();
		content = "%" + content + "%";
		
		System.out.println("-----------------------------------------------------------------------------");
		System.out.println(" 번호\t제목\t작성자\t작성날짜\t\t내용");
		System.out.println("-----------------------------------------------------------------------------");
			
		List<BoardVO> boardList = service.getSearchContent(content);
		for(BoardVO bv : boardList) {
			System.out.println(bv.getBoard_no() + "\t" 
									+ bv.getBoard_title() + "\t" 
									+ bv.getBoard_writer() + "\t"
									+ bv.getBoard_date() + "\t"
									+ bv.getBoard_content());
		}
			
		System.out.println("-----------------------------------------------------------------------------");
		System.out.println("더 이상 조회할 게시글이 없습니다.");
	}

	//작성자로 검색
	private void writerSearch() {
		System.out.println();
		System.out.println("검색할 작성자 아이디를 입력하세요.");
		String writer = scan.nextLine();
		writer = "%" + writer + "%";
			
		System.out.println("-----------------------------------------------------------------------------");
		System.out.println(" 번호\t제목\t작성자\t작성날짜\t\t내용");
		System.out.println("-----------------------------------------------------------------------------");
			
		List<BoardVO> boardList = service.getSearchWriter(writer);
		for(BoardVO bv : boardList) {
			System.out.println(bv.getBoard_no() + "\t" 
									+ bv.getBoard_title() + "\t" 
									+ bv.getBoard_writer() + "\t"
									+ bv.getBoard_date() + "\t"
									+ bv.getBoard_content());
		}
					
		System.out.println("-----------------------------------------------------------------------------");
		System.out.println("더 이상 조회할 게시글이 없습니다.");
		
	}

	//제목으로 검색
	private void titleSearch() {
		System.out.println();
		System.out.println("검색할 제목을 입력하세요.");
		String title = scan.nextLine();
		title = "%" + title + "%";
		
		System.out.println("-----------------------------------------------------------------------------");
		System.out.println(" 번호\t제목\t작성자\t작성날짜\t\t내용");
		System.out.println("-----------------------------------------------------------------------------");
			
		
		List<BoardVO> boardList = service.getSearchTitle(title);
		for(BoardVO bv : boardList) {
			System.out.println(bv.getBoard_no() + "\t" 
									+ bv.getBoard_title() + "\t" 
									+ bv.getBoard_writer() + "\t"
									+ bv.getBoard_date() + "\t"
									+ bv.getBoard_content());
		}
					
		System.out.println("-----------------------------------------------------------------------------");
		System.out.println("더 이상 조회할 게시글이 없습니다.");
	}

	//게시글 삭제
	private void deleteBoard() {
		System.out.println();
		String boardWriter = "";
		boolean check = true;
		
		do {
			System.out.println();
			System.out.println("회원님의 아이디를 입력하세요 >> ");
			boardWriter = scan.nextLine();
			
			check = service.getWriter(boardWriter);
			
			if(check == false) {
				System.out.println(boardWriter + "님이 작성하신 글이 없습니다.");
			}
		}while(check == false);
	
		System.out.println();
		System.out.println("-----------------------------------------------------------------------------");
		System.out.println(" 번호\t제목\t작성자\t작성날짜\t\t내용");
		System.out.println("-----------------------------------------------------------------------------");
		
		List<BoardVO> boardList = service.updateList(boardWriter);
		for(BoardVO bv : boardList) {
			System.out.println(bv.getBoard_no() + "\t" 
									+ bv.getBoard_title() + "\t" 
									+ bv.getBoard_writer() + "\t"
									+ bv.getBoard_date() + "\t"
									+ bv.getBoard_content());
		}
		System.out.println("-----------------------------------------------------------------------------");
		System.out.println("더 이상 조회할 게시글이 없습니다.");
	
		System.out.println("삭제할 게시글 번호를 입력하세요.");
		String num = scan.nextLine();
		
		BoardVO bv = new BoardVO();
		bv.setBoard_no(num);
		bv.setBoard_writer(boardWriter);
		
		int cnt = service.deleteBoard(bv);
		
		if(cnt > 0) {
			System.out.println(boardWriter + "님의 게시글을 삭제했습니다.");
		}else {
			System.out.println("게시글 삭제가 정상적으로 이루어지지 않았습니다.");
		}
	}

	//게시글 수정
	private void updateBoard() {
		System.out.println();
		String boardWriter = "";
		boolean check = true;
		
		do {
			System.out.println("회원님의 아이디를 입력하세요 >> ");
			boardWriter = scan.nextLine();
			
			check = service.getWriter(boardWriter);
			if(check == false) {
				System.out.println(boardWriter + "님이 작성하신 글이 없습니다.");
			}
		}while(check == false);
				
		System.out.println();
		System.out.println("-----------------------------------------------------------------------------");
		System.out.println(" 번호\t제목\t작성자\t작성날짜\t\t내용");
		System.out.println("-----------------------------------------------------------------------------");
		
		List<BoardVO> boardList = service.updateList(boardWriter);
		for(BoardVO bv : boardList) {
			System.out.println(bv.getBoard_no() + "\t" 
									+ bv.getBoard_title() + "\t" 
									+ bv.getBoard_writer() + "\t"
									+ bv.getBoard_date() + "\t"
									+ bv.getBoard_content());
		}
		System.out.println("-----------------------------------------------------------------------------");
		System.out.println("더 이상 조회할 게시글이 없습니다.");
		
		System.out.println("수정할 게시글의 번호를 입력하세요.");
		String num = scan.nextLine();
	
		System.out.println("수정할 내용을 입력하세요.");
		System.out.println("새로운 제목 >> ");
		String boardTitle = scan.nextLine();
		
		System.out.println("새로운 내용 >> ");
		String boardContent = scan.nextLine();
			
		BoardVO bv = new BoardVO();
		bv.setBoard_no(num);
		bv.setBoard_title(boardTitle);
		bv.setBoard_writer(boardWriter);
		bv.setBoard_content(boardContent);
		
		int cnt = service.updateBoard(bv);
		
		if(cnt > 0) {
			System.out.println(boardWriter + "님의 게시글을 수정했습니다.");
		}else {
			System.out.println("게시글 수정에 실패했습니다");
		}
	}
	
	//새 게시글 등록
	private void insertBoard() {
		System.out.println("제목 >> ");
		String boardTitle = scan.nextLine();
		
		System.out.println("작성자 >> ");
		String boardWriter = scan.nextLine();
		
		System.out.println("내용 >> ");
		String boardContent = scan.nextLine();
	
		BoardVO bv = new BoardVO();
		bv.setBoard_title(boardTitle);
		bv.setBoard_writer(boardWriter);
		bv.setBoard_content(boardContent);
			
		int cnt = service.insertBoard(bv);
		
		if(cnt > 0) {
			System.out.println(boardWriter + "님이 작성하신 게시글이 정상등록 되었습니다.");
		}else {
			System.out.println("게시글 등록이 정상적으로 이루어지지 않았습니다.");
		}
	}

	//전체 게시글 목록 출력
	private void listAllBoard() {
		System.out.println();
		System.out.println("-----------------------------------------------------------------------------");
		System.out.println(" 번호\t제목\t작성자\t작성날짜\t\t내용");
		System.out.println("-----------------------------------------------------------------------------");
		
		List<BoardVO> boardList = service.getAllBoardList();
		for(BoardVO bv : boardList) {
			System.out.println(bv.getBoard_no() + "\t" 
									+ bv.getBoard_title() + "\t" 
									+ bv.getBoard_writer() + "\t"
									+ bv.getBoard_date() + "\t"
									+ bv.getBoard_content());
		}
		System.out.println("-----------------------------------------------------------------------------");
		System.out.println("더 이상 조회할 게시글이 없습니다.");
	
	}
	
	//메인 메서드
	public static void main(String[] args) {
		BoardOperate bos = new BoardOperate();
		bos.start();
	}
}
