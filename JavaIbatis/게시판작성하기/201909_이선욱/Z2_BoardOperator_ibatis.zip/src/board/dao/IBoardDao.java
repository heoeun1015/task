package board.dao;

import java.util.List;

import board.vo.BoardVO;

/**
 * 실제 DB와 연결해서 SQL문을 수행한 다음 결과를 작성하여 service에 전달하는 
 * DAO의 interface
 * @author pc18 
 */
public interface IBoardDao {

	public int insertBoard(BoardVO bv);
	

	public boolean getWriter(String boardWriter);
	

	public List<BoardVO> getAllBoardList();


	public int updateBoard(BoardVO bv);
	
	
	public List<BoardVO> updateList(String boardWriter);


	public int deleteBoard(BoardVO bv);


	public List<BoardVO> getSearchTitle(String title);
	
	
	public List<BoardVO> getSearchContent(String content);
	
	
	public List<BoardVO> getSearchWriter(String writer);
	
}
