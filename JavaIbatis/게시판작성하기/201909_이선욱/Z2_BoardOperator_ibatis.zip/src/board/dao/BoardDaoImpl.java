package board.dao;

import java.io.IOException;
import java.io.Reader;
import java.nio.charset.Charset;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;


import com.ibatis.common.resources.Resources;
import com.ibatis.sqlmap.client.SqlMapClient;
import com.ibatis.sqlmap.client.SqlMapClientBuilder;

import board.vo.BoardVO;

public class BoardDaoImpl implements IBoardDao {
	private SqlMapClient smc;
	
	private static IBoardDao dao;
	
	private BoardDaoImpl() {
		Reader rd;
		
		try {
			Charset charset = Charset.forName("UTF-8");
			Resources.setCharset(charset);
			
			rd = Resources.getResourceAsReader("SqlMapConfig.xml");
		
			smc = SqlMapClientBuilder.buildSqlMapClient(rd);
			
			rd.close();
		}catch (IOException e) {
			System.out.println("SqlMap객체 생성 실패!!!");
			e.printStackTrace();
		}
	}
	
	public static IBoardDao getInstance() {
		
		if(dao == null) {
			dao = new BoardDaoImpl();
		}
		return dao;
	}
	
	//새 게시글 작성
	@Override
	public int insertBoard(BoardVO bv) {
		int cnt = 0;
		
		try {
			Object obj = smc.insert("board.insertBoard", bv);
			if(obj == null) {
				cnt = 1;
			}
		}catch(SQLException e) {
			e.printStackTrace();
		}
		
		return cnt;
	}

	//작성자가 있는지 확인
	@Override
	public boolean getWriter(String boardWriter) {
		boolean check = false;
		
		int cnt = 0;
		
		try {
			
			cnt = (int) smc.queryForObject("board.getWriter", boardWriter);
			
			if(cnt > 0) {
				check = true;
			}
		}catch(SQLException e) {
			e.printStackTrace();
		}
		
		return check;
	}

	//전체 게시글 출력
	@Override
	public List<BoardVO> getAllBoardList() {
		List<BoardVO> boardList = new ArrayList<BoardVO>();
		
		try {
			
			boardList = smc.queryForList("board.getAllBoardList");
			
		}catch(SQLException e) {
			e.printStackTrace();
		}
		
		return boardList;
	}

	//게시글 수정
	@Override
	public int updateBoard(BoardVO bv) {
		int cnt = 0;
		
		try {
			
			cnt = smc.update("board.updateBoard", bv);
			
		}catch(SQLException e) {
			e.printStackTrace();
		}
		
		return cnt;
	}
	
	//게시글 수정 전 수정할 수 있는 글 목록 출력
	@Override
	public List<BoardVO> updateList(String boardWriter){
		List<BoardVO> boardList = new ArrayList<BoardVO>();
		
		try {
			
			boardList = smc.queryForList("board.updateList", boardWriter);
			
		}catch(SQLException e) {
			e.printStackTrace();
		}
		
		return boardList;
	}
	

	//게시글 삭제
	@Override
	public int deleteBoard(BoardVO bv) {
		int cnt = 0;
		try {
			
			cnt = smc.delete("board.deleteBoard", bv);
			
		}catch(SQLException e) {
			e.printStackTrace();
		}
		
		return cnt;
	}

	//제목 검색
	@Override
	public List<BoardVO> getSearchTitle(String title) {
		List<BoardVO> boardList = new ArrayList<BoardVO>();
		
		try {
			boardList = smc.queryForList("board.getSearchTitle", title);
			
		}catch(SQLException e) {
			e.printStackTrace();
		}
		
		return boardList;
	}
	
	//내용 검색
	@Override
	public List<BoardVO> getSearchContent(String content) {
		List<BoardVO> boardList = new ArrayList<BoardVO>();
		
		try {
			
			boardList = smc.queryForList("board.getSearchContent", content);
			
		}catch(SQLException e) {
			e.printStackTrace();
		}
		return boardList;
	}
	
	//작성자 검색
	@Override
	public List<BoardVO> getSearchWriter(String writer) {
		List<BoardVO> boardList = new ArrayList<BoardVO>();
		
		try {
			
			boardList = smc.queryForList("board.getSearchWriter", writer);
			
		}catch(SQLException e) {
			e.printStackTrace();
		}
		
		return boardList;
	}
}
