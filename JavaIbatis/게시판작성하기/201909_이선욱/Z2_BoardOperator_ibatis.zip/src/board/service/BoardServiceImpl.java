package board.service;

import java.util.List;

import board.dao.BoardDaoImpl;
import board.dao.IBoardDao;
import board.vo.BoardVO;

public class BoardServiceImpl implements IBoardService {
	
	private static BoardServiceImpl service;
	
	//사용할 DAO의 객체변수를 선언한다.
	private IBoardDao boardDao;
	
	private BoardServiceImpl() {
		boardDao = BoardDaoImpl.getInstance(); // MemberServiceImpl 호출될때 MemberDaoImpl 같이 만들어짐.
	}
	
	public static BoardServiceImpl getInstance() {
		if(service == null) {
			service = new BoardServiceImpl();
		}
		return service;
	}
	
	@Override
	public int insertBoard(BoardVO bv) {
		
		return boardDao.insertBoard(bv);
	}

	@Override
	public boolean getWriter(String boardWriter) {
		
		return boardDao.getWriter(boardWriter);
	}

	@Override
	public List<BoardVO> getAllBoardList() {
		
		return boardDao.getAllBoardList();
	}

	@Override
	public int updateBoard(BoardVO bv) {
		
		return boardDao.updateBoard(bv);
	}
	
	@Override
	public List<BoardVO> updateList(String boardWriter){
		
		return boardDao.updateList(boardWriter);
	}


	@Override
	public int deleteBoard(BoardVO bv) {
		
		return boardDao.deleteBoard(bv);
	}

	@Override
	public List<BoardVO> getSearchTitle(String title) {
		
		return boardDao.getSearchTitle(title);
	}

	@Override
	public List<BoardVO> getSearchContent(String content) {
		
		return boardDao.getSearchContent(content);
	}

	@Override
	public List<BoardVO> getSearchWriter(String writer) {
		
		return boardDao.getSearchWriter(writer);
	}

}
