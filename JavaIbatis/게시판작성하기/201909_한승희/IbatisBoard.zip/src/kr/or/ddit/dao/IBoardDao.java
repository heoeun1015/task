package kr.or.ddit.dao;

import java.util.List;

import kr.or.ddit.vo.MVCBoardVO;

public interface IBoardDao {
	public MVCBoardVO getSearchList(int number);
	
	public int getDeleteList(int number);
	
	public int getUpdateList(MVCBoardVO mv);
	
	public List<MVCBoardVO> getViewAll();
	
	public int getWriteList(MVCBoardVO mv);
}
