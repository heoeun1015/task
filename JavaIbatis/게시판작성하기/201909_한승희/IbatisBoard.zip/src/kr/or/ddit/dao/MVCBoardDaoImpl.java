package kr.or.ddit.dao;

import java.io.IOException;
import java.io.Reader;
import java.nio.charset.Charset;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.ibatis.common.resources.Resources;
import com.ibatis.sqlmap.client.SqlMapClient;
import com.ibatis.sqlmap.client.SqlMapClientBuilder;

import kr.or.ddit.util.DBUtil3;
import kr.or.ddit.vo.MVCBoardVO;

public class MVCBoardDaoImpl implements IBoardDao{
	private SqlMapClient smc;

	private static MVCBoardDaoImpl instance;
	
	private MVCBoardDaoImpl() {
		
		try {
			//1. xml문서 읽기
			Charset charset = Charset.forName("UTF-8");	//설정파일 인코딩
			
			Resources.setCharset(charset);
			
			Reader rd = Resources.getResourceAsReader("sqlMapConfig.xml");
			
			//2. Reader 객체를 사용하여 실제 작업을 진행할 객체 생성
			smc = SqlMapClientBuilder.buildSqlMapClient(rd);
			
			rd.close();
		} catch (IOException e) {
			System.out.println("SqlMapClient 생성 실패");
		}
		
	};
	
	public static MVCBoardDaoImpl getInstance()
	{
		if(instance == null)
		{
			instance = new MVCBoardDaoImpl();
		}
		
		return instance;
	}

	@Override
	public MVCBoardVO getSearchList(int number) {
		MVCBoardVO mv = new MVCBoardVO();
		
		try {
			mv = (MVCBoardVO) smc.queryForObject("board.searchList", number);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return mv;
	}

	@Override
	public int getDeleteList(int number) {
		int cnt=0;
		
		try {
			cnt = smc.delete("board.deleteList", number);
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return cnt;
	}

	@Override
	public int getUpdateList(MVCBoardVO mv) {
		int cnt=0;
		
		try {
			cnt = smc.update("board.updateList", mv);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return cnt;
	}

	@Override
	public List<MVCBoardVO> getViewAll() {
		List<MVCBoardVO> boardList = new ArrayList<MVCBoardVO>();
		
		try {
			boardList = smc.queryForList("board.viewAll");
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return boardList;
	}

	@Override
	public int getWriteList(MVCBoardVO mv) {
		int cnt=0;
		try {
			Object obj = smc.insert("board.writeList", mv);
			
			if(obj==null)
			{
				cnt=1;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return cnt;
	}
}
