//  시퀀스이름.nextVal
/*
create table jdbc_board(
    board_no number not null,  -- 번호(자동증가)
    board_title varchar2(100) not null, -- 제목
    board_writer varchar2(50) not null, -- 작성자
    board_date date not null,   -- 작성날짜
    board_content clob,     -- 내용
    constraint pk_jdbc_board primary key (board_no)
);
	create sequence board_seq
    start with 1   -- 시작번호
    increment by 1; -- 증가값
 */
package kr.or.ddit;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Scanner;

import kr.or.ddit.service.IBoardService;
import kr.or.ddit.service.MVCBoardServiceImpl;
import kr.or.ddit.vo.MVCBoardVO;

public class MVCBoardMain {

	SimpleDateFormat format = new SimpleDateFormat("yy/MM/dd");
	
	private Scanner scan = new Scanner(System.in); 
	
	private IBoardService service = MVCBoardServiceImpl.getInstance();
	/**
	 * 메뉴를 출력하는 메서드
	 */
	public void displayMenu(){
		System.out.println();
		System.out.println("----------------------");
		System.out.println("  === 작 업 선 택 ===");
		System.out.println("  1. 전체 목록 출력");
		System.out.println("  2. 새 글 작성");
		System.out.println("  3. 글 수정");
		System.out.println("  4. 글 삭제");
		System.out.println("  5. 검색");
		System.out.println("  -1. 종료");
		System.out.println("----------------------");
		System.out.print("원하는 작업 선택 >> ");
	}
	
	/**
	 * 프로그램 시작메서드
	 */
	public void start(){
		int choice;
		do{
			displayMenu(); //메뉴 출력
			choice = Integer.parseInt(scan.nextLine()); // 메뉴번호 입력받기
			switch(choice){
				case 1 :  // 전체 목록 출력
					viewAll();
					break;
				case 2 :  // 새 글 작성
					writeList();
					break;
				case 3 :  // 글 수정
					updateList();
					break;
				case 4 :  // 글 삭제
					deleteList();
					break;
				case 5 :  // 검색
					searchList();
					break;
				case -1 :
					System.out.println("작업을 마칩니다.");
					break;
				default :
					System.out.println("번호를 잘못 입력했습니다. 다시입력하세요");
			}
		}while(choice!=-1);
	}
	
	//자료 검색
	private void searchList() {
		int number;
		
		System.out.print("검색할 글 번호를 입력해주세요 >> ");
		number = Integer.parseInt(scan.nextLine());
		
		MVCBoardVO mv = service.getSearchList(number);
		
		System.out.println("\n===================================");
		
		if(mv==null)
		{
			System.out.println("지금 입력하신 번호는 없는 번호입니다.");
		}
		else
		{			
			System.out.println("\n"+ number +"번째 글을 검색합니다.");
			System.out.println("번호 : " + mv.getBoard_no());
			System.out.println("제목 : " + mv.getBoard_title());
			System.out.println("작성자 : " + mv.getBoard_writer());
			System.out.println("날짜 : " + format.format(mv.getBoard_date()));
			System.out.println("내용 : " + mv.getBoard_content() + "\n");
		}
	}
	
	//글 삭제
	private void deleteList() {
		
		int number;
		
		System.out.print("삭제할 글 번호를 입력해주세요 >> ");
		number = Integer.parseInt(scan.nextLine());
		
		MVCBoardVO mv = service.getSearchList(number);
		
		if(mv==null)
		{
			System.out.println("지금 입력하신 번호는 없는 번호입니다.");
		}
		else
		{			
			if(service.getDeleteList(number)>0)
			{
				System.out.println("\n"+ number +"번째 글이 삭제되었습니다.");
			}
			else
			{
				System.out.println("\n오류가 발생하여 글 삭제가 취소되었습니다.");
			}
		}
	}

	//글 수정
	private void updateList() {
		int number;
		String title=null, writer=null, content=null;
		
		System.out.print("\n수정할 글 번호를 입력해주세요 >> ");
		number = Integer.parseInt(scan.nextLine());
		
		MVCBoardVO mv = service.getSearchList(number);
		
		if(mv==null)
		{
			System.out.println("지금 입력하신 번호는 없는 번호입니다.");
		}
		else
		{
			System.out.print("수정할 제목을 입력해주세요 >> ");
			title = scan.nextLine();
			System.out.print("수정할 작성자를 입력해주세요 >> ");
			writer = scan.nextLine();
			System.out.print("수정할 내용을 입력해주세요 >> ");
			content = scan.nextLine();
			
			MVCBoardVO mv1 = new MVCBoardVO();
			
			mv1.setBoard_no(number);
			mv1.setBoard_title(title);
			mv1.setBoard_writer(writer);
			mv1.setBoard_content(content);
			mv1.setBoard_date(new Date());
			
			if(service.getUpdateList(mv1)>0)
			{
				System.out.println("\n"+ number +"번째 글이 수정되었습니다.");
			}
			else
			{
				System.out.println("\n오류가 발생하여 글 수정이 취소되었습니다.");
			}
		}
	}

	//전체 목록 출력
	private void viewAll() {
		List<MVCBoardVO> boardList = service.getViewAll();
		
		System.out.println("\n========================================");
		System.out.println("번호\t제목\t작성자\t작성날짜\t내용");
		
		if(boardList==null)
		{
			System.out.println("데이터가 존재하지 않습니다.");
		}
		else
		{
			for(MVCBoardVO mv : boardList)				
			{
				System.out.println(mv.getBoard_no()+"\t"
						+mv.getBoard_title()+"\t"
						+mv.getBoard_writer()+"\t"
						+format.format(mv.getBoard_date())+"\t"
						+mv.getBoard_content());
			}
		}
		System.out.println("========================================\n");
	}

	//새 글 작성
	private void writeList() {
		
		String title = null, writer = null, content = null;
		
		System.out.println("\n새 글을 작성합니다.");
		System.out.print("글 제목을 입력해주세요 >> ");
		title = scan.nextLine();
		System.out.print("작성자를 입력해주세요 >> ");
		writer = scan.nextLine();
		System.out.print("글 내용을 입력해주세요 >> ");
		content = scan.nextLine();
		
		MVCBoardVO mv = new MVCBoardVO();
		
		mv.setBoard_title(title);
		mv.setBoard_writer(writer);
		mv.setBoard_content(content);
		mv.setBoard_date(new Date());
		
		if(service.getWriteList(mv)>0)
		{
			System.out.println("\n새 글이 작성되었습니다.");
		}
		else
		{
			System.out.println("\n오류가 발생하여 글 작성이 취소되었습니다.");
		}
	}
	
	public static void main(String[] args) {
		MVCBoardMain memObj = new MVCBoardMain();
		memObj.start();
	}
}
