package kr.or.ddit.service;

import java.util.List;

import kr.or.ddit.dao.MVCBoardDaoImpl;
import kr.or.ddit.vo.MVCBoardVO;

public class MVCBoardServiceImpl implements IBoardService{

	private static MVCBoardServiceImpl instance;
	
	private MVCBoardServiceImpl() {};
	
	public static MVCBoardServiceImpl getInstance()
	{
		if(instance == null)
		{
			instance = new MVCBoardServiceImpl();
		}
		
		return instance;
	}
	
	private MVCBoardDaoImpl boardDao = MVCBoardDaoImpl.getInstance();

	@Override
	public MVCBoardVO getSearchList(int number) {
		return boardDao.getSearchList(number);
	}

	@Override
	public int getDeleteList(int number) {
		return boardDao.getDeleteList(number);
	}

	@Override
	public int getUpdateList(MVCBoardVO mv) {
		return boardDao.getUpdateList(mv);
	}

	@Override
	public List<MVCBoardVO> getViewAll() {
		return boardDao.getViewAll();
	}

	@Override
	public int getWriteList(MVCBoardVO mv) {
		return boardDao.getWriteList(mv);
	}
}
