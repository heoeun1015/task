package kr.or.ddit.service;

import java.util.List;

import kr.or.ddit.vo.MVCBoardVO;

public interface IBoardService {
	public MVCBoardVO getSearchList(int number);
	
	public int getDeleteList(int number);
	
	public int getUpdateList(MVCBoardVO mv);
	
	public List<MVCBoardVO> getViewAll();
	
	public int getWriteList(MVCBoardVO mv);
}
