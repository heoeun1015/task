package kr.or.ddit;

import java.sql.SQLException;
import java.util.List;
import java.util.Scanner;

import kr.or.ddit.board.service.BoardServiceImpl;
import kr.or.ddit.board.service.IBoardService;
import kr.or.ddit.board.vo.BoardVO;
import kr.or.ddit.util.DBUtil;

public class BoardMain {
	private Scanner scan = new Scanner(System.in);
	
	private IBoardService service;
	
	public BoardMain() {
		service = BoardServiceImpl.getInstance();
	}
	
	
	/**
	 * 메뉴를 출력하는 메서드
	 */
	public void displayMenu(){
		System.out.println();
		System.out.println("----------------------");
		System.out.println("  === 작 업 선 택 ===");
		System.out.println("  1. 게시글 작성");
		System.out.println("  2. 게시글 수정");
		System.out.println("  3. 게시글 삭제");
		System.out.println("  4. 전체 게시글 출력");
		System.out.println("  5. 검색");
		System.out.println("  6. 종료");
		System.out.println("----------------------");
		System.out.print("원하는 작업 선택 >> ");
	}
	/**
	 * 프로그램 시작메서드
	 */
	public void start(){
		int choice;
		do{
			displayMenu(); //메뉴 출력
			choice = scan.nextInt(); // 메뉴번호 입력받기
			switch(choice){
				case 1 :  // 게시글 작성
					insertBoard();
					break;
				case 2 :  // 게시글 수정
					updateBoard();
					break;
				case 3 :  // 게시글 삭제
					deleteBoard();
					break;
				case 4 :  // 전체 게시글 출력
					displayBoardAll();
					break;
				case 5 :  // 검색
					searchBoard();
					break;
				case 6 :  // 작업 끝
					System.out.println("작업을 마칩니다.");
					break;
				default :
					System.out.println("번호를 잘못 입력했습니다. 다시입력하세요");
			}
		}while(choice!=6);
	}
	//게시글 검색 메서드
	private void searchBoard() {
		scan.nextLine();
		System.out.println();
		System.out.println("검색할 정보를 입력하세요.");
		System.out.println("게시글 번호 >> ");
		String boardNo = scan.nextLine().trim();
		System.out.println("게시글 제목 >> ");
		String boardTitle = scan.nextLine().trim();
		System.out.println("게시글 작성자 >> ");
		String boardWriter = scan.nextLine().trim();
		System.out.println("게시글 등록날짜 >> ");
		String boardDate = scan.nextLine().trim();
		System.out.println("게시글 내용 >> ");
		String boardContent = scan.nextLine().trim();
		
		BoardVO bv = new BoardVO();
		bv.setBoard_no(boardNo);
		bv.setBoard_title(boardTitle);
		bv.setBoard_writer(boardWriter);
		bv.setBoard_date(boardDate);
		bv.setBoard_content(boardContent);
		
		List<BoardVO> boardList = service.getSearchBoard(bv);
		System.out.println();
		System.out.println("------------------------------------------------");
		System.out.println(" 게시글 번호\t제목\t작성자\t작성날짜\t\t\t내용");
		System.out.println("------------------------------------------------");
		
		if(boardList == null || boardList.size() == 0) {
			System.out.println("게시글이 하나도 없습니다.");
		}else {
			for(BoardVO bv2 : boardList) {
				System.out.println(bv2.getBoard_no() + "\t" + bv2.getBoard_title() 
						+ "\t" + bv2.getBoard_writer() + "\t" + bv2.getBoard_date()
						+ "\t" + bv2.getBoard_content());
			}
		}
		
		System.out.println("------------------------------------------------");
		System.out.println("출력 작업 끝...");
		
	}
	//전체 게시글 출력 메서드
	private void displayBoardAll() {
		System.out.println();
		System.out.println("------------------------------------------------");
		System.out.println(" 게시글 번호\t제목\t작성자\t작성날짜\t\t\t내용");
		System.out.println("------------------------------------------------");
		
		List<BoardVO> boardList = service.getAllBoardList();
		
		for(BoardVO bv : boardList) {
			System.out.println(bv.getBoard_no() + "\t" + bv.getBoard_title() 
							+ "\t" + bv.getBoard_writer() 
							+ "\t" + bv.getBoard_date()
							+ "\t" + bv.getBoard_content());
		}
		System.out.println("------------------------------------------------");
		System.out.println("출력 작업 끝...");
	
	}
	//게시글 삭제 메서드
	private void deleteBoard() {
		System.out.println();
		System.out.println("삭제할 게시글 번호를 입력하세요.");
		String boardNo = scan.next();
	
		int cnt = service.deleteBoard(boardNo);
		if(cnt > 0) {
			System.out.println(boardNo + "번 게시글 삭제 성공..");
		}else {
			System.out.println(boardNo + "번 게시글 삭제 실패!");
		}
	}
	//게시글 수정 메서드
	private void updateBoard() {
		System.out.println();
		String boardNo ;
		boolean chk = true;
		
		do {
			System.out.println("수정할 게시글 번호를 입력하세요 >> ");
			boardNo = scan.next();
			
			chk = service.getBoard(boardNo);
			if(chk == false) {
				System.out.println(boardNo + "번 게시글은 없습니다.");
				System.out.println("수정할 게시글이 없으니 다시 입력하세요.");
			}
		}while(chk == false);
		 
		System.out.println("수정할 내용을 입력하세요.");
		System.out.println("수정할 게시글 제목 >> ");
		String boardTitle = scan.next();
		
		scan.nextLine();
		System.out.println("수정할 게시글 내용 >> ");
		String boardContent = scan.nextLine();
		
		BoardVO bv = new BoardVO();
		bv.setBoard_no(boardNo);
		bv.setBoard_title(boardTitle);
		bv.setBoard_content(boardContent);
		
		
		int cnt = service.updateBoard(bv);
		
		if(cnt > 0) {
			System.out.println(boardNo + "번 게시글을 수정했습니다.");
		}else {
			System.out.println("게시글 수정 실패!");
		}
			
		
	}
	//게시글 작성 메서드
	private void insertBoard() {
				
		System.out.println();
		System.out.println("게시글 제목을 입력하세요");
		System.out.println("제목 >> ");
		String boardTitle = scan.next();
			
		
		System.out.println("작성자 명 >> ");
		String boardWriter = scan.next();
		
		scan.nextLine(); //입력버퍼 바꾸기
		
		System.out.println("내용 >> ");
		String boardContent = scan.nextLine();
		
		BoardVO bv = new BoardVO();
		bv.setBoard_title(boardTitle);
		bv.setBoard_writer(boardWriter);
		bv.setBoard_content(boardContent);
		
		int cnt = service.insertBoard(bv);
		
		if(cnt > 0) {
			System.out.println("게시글이 등록되었습니다.");
		}else {
			System.out.println("게시글 등록 실패!");
		}
	
		
	}
	
	public static void main(String[] args) {
		BoardMain boardObj = new BoardMain();
		boardObj.start();
	}

}
