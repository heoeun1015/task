package kr.or.ddit.board.service;

import java.util.List;

import kr.or.ddit.board.vo.BoardVO;

public interface IBoardService {

	public int insertBoard (BoardVO bv);
	
	public boolean getBoard(String board_no);
	
	public List<BoardVO> getAllBoardList();
	
	public int updateBoard (BoardVO bv);
	
	public int deleteBoard (String board_no);
	
	public List<BoardVO> getSearchBoard(BoardVO bv);
	
}
