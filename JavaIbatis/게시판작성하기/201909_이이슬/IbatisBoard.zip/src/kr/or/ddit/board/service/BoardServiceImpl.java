package kr.or.ddit.board.service;

import java.util.List;

import kr.or.ddit.board.dao.BoardDaoImpl;
import kr.or.ddit.board.dao.IBoardDao;
import kr.or.ddit.board.vo.BoardVO;

public class BoardServiceImpl implements IBoardService {
	
	private static BoardServiceImpl service;
	
	private IBoardDao boardDao;
	
	private BoardServiceImpl() {
		boardDao = BoardDaoImpl.getInstance();
	}
	
	public static BoardServiceImpl getInstance() {
		if(service == null) {
			service = new BoardServiceImpl();
		}
		return service;
	}
	
	@Override
	public int insertBoard(BoardVO bv) {
		
		return boardDao.insertBoard(bv);
	}

	@Override
	public boolean getBoard(String board_no) {
		return boardDao.getBoard(board_no);
	}

	@Override
	public List<BoardVO> getAllBoardList() {
		return boardDao.getAllBoardList();
	}

	@Override
	public int updateBoard(BoardVO bv) {
		return boardDao.updateBoard(bv);
	}

	@Override
	public int deleteBoard(String board_no) {
		return boardDao.deleteBoard(board_no);
	}

	@Override
	public List<BoardVO> getSearchBoard(BoardVO bv) {
		return boardDao.getSearchBoard(bv);
	}

}
