package kr.or.ddit.board.dao;

import java.io.IOException;
import java.io.Reader;
import java.nio.charset.Charset;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.ibatis.common.resources.Resources;
import com.ibatis.sqlmap.client.SqlMapClient;
import com.ibatis.sqlmap.client.SqlMapClientBuilder;

import kr.or.ddit.board.vo.BoardVO;

public class BoardDaoImpl implements IBoardDao {

	private SqlMapClient smc;

	private static BoardDaoImpl boarddao;

	private BoardDaoImpl() {
		
		Reader rd;

		try {
			Charset charset = Charset.forName("UTF-8"); // 설정파일인코딩
			Resources.setCharset(charset);

			rd = Resources.getResourceAsReader("sqlMapConfig.xml");

			smc = SqlMapClientBuilder.buildSqlMapClient(rd);

			rd.close();

		} catch (IOException e) {
			System.out.println("SqlMapClient객체 생성 실패!!!");
			e.printStackTrace();
		}
	}

	public static BoardDaoImpl getInstance() {
		if (boarddao == null) {
			boarddao = new BoardDaoImpl();
		}

		return boarddao;
	}

	@Override
	public List<BoardVO> displayAll() {

		List<BoardVO> allList = new ArrayList<BoardVO>();

		try {
			allList = smc.queryForList("board.allList");
		} catch (SQLException e) {
			
			e.printStackTrace();
		}

		return allList;
	}

	@Override
	public int newWrite(BoardVO board) {

		int cnt = 0;

		try {

			Object obj = smc.insert("board.insertBoard", board);
			
			if(obj == null) {
				cnt = 1;
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return cnt;
	}

	@Override
	public int modifyWrite(BoardVO board) {

		int cnt = 0;

		try {

			cnt = smc.update("board.updateBoard", board);

		} catch (SQLException e) {
			e.printStackTrace();
		}
		return cnt;
	}

	@Override
	public int deleteWrite(int boardNum) {

		int cnt = 0;

		try {

			cnt = smc.delete("board.deleteBoard", boardNum);

		} catch (SQLException e) {
			e.printStackTrace();
		}
		return cnt;
	}

	@Override
	public List<BoardVO> search(BoardVO board) {

		List<BoardVO> searchList = null;
		try {
			searchList = smc.queryForList("board.search", board);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return searchList;
	}
}