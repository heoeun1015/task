package kr.or.ddit.board.service;

import java.util.List;

import kr.or.ddit.board.vo.BoardVO;

public interface IBoardService {
	public List<BoardVO> displayAll();

	public int newWrite(BoardVO board);

	public int modifyWrite(BoardVO board);

	public int deleteWrite(int boardNum);

	public List<BoardVO> search(BoardVO board);
}
