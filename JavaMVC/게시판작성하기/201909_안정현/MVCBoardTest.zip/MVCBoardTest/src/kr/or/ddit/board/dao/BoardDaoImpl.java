package kr.or.ddit.board.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import kr.or.ddit.board.main.BoardMain;
import kr.or.ddit.board.vo.BoardVO;
import kr.or.ddit.util.DBUtil;
import kr.or.ddit.util.DBUtil2;

public class BoardDaoImpl implements IBoardDao {
	private Connection conn;
	private Statement stmt;
	private PreparedStatement pstmt;
	private ResultSet rs;
	
	private static final Logger sqlLogger = Logger.getLogger("log4jexam.sql.Query");
	private static final Logger paramLogger = Logger.getLogger("log4jexam.sql.Parameter");
	private static final Logger resultLogger = Logger.getLogger(BoardMain.class);

	private static BoardDaoImpl boarddao;

	private BoardDaoImpl() {

	}

	public static BoardDaoImpl getInstance() {
		if (boarddao == null) {
			boarddao = new BoardDaoImpl();
		}

		return boarddao;
	}

	@Override
	public List<BoardVO> displayAll() {

		List<BoardVO> allList = new ArrayList<BoardVO>();

		try {
			conn = DBUtil2.getConnection();
			stmt = conn.createStatement();
			String sql = "SELECT * FROM jdbc_board";
			rs = stmt.executeQuery(sql);

			while (rs.next()) {
				BoardVO temp = new BoardVO();
				temp.setBoardnum(rs.getInt("board_no"));
				temp.setTitle(rs.getString("board_title"));
				temp.setDate(rs.getDate("board_date"));
				temp.setWriter(rs.getString("board_writer"));
				temp.setContent(rs.getString("board_content"));
				allList.add(temp);
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			disConnect();
		}
		return allList;
	}

	@Override
	public int newWrite(BoardVO board) {

		int cnt = 0;

		try {
			conn = DBUtil2.getConnection();
			String sql = "INSERT INTO jdbc_board (board_no, board_title, board_writer, "
					+ "board_date, board_content) VALUES (board_seq.nextVal, ?, ?, sysdate, ?)";

			sqlLogger.debug("쿼리 : " + sql);
			
			
			pstmt = conn.prepareStatement(sql);

			pstmt.setString(1, board.getTitle());
			pstmt.setString(2, board.getWriter());
			pstmt.setString(3, board.getContent());
			
			paramLogger.debug("파라미터 : " 
	                  + "(" + board.getTitle() + ", "
	                  + board.getWriter() + ", "
	                  + board.getContent() + ")");
			

			cnt = pstmt.executeUpdate();
			
			resultLogger.debug("결과 : " + cnt);

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			disConnect();
		}
		return cnt;
	}

	@Override
	public int modifyWrite(BoardVO board) {
		
		int cnt = 0;
		
		try {
			conn = DBUtil2.getConnection();
			String sql = "UPDATE jdbc_board SET "
					     + "board_title = ?, "
					     + "board_writer = ?, "
					     + "board_content = ? "
					     + "WHERE board_no = ?";
			pstmt = conn.prepareStatement(sql);

			pstmt.setString(1, board.getTitle());
			pstmt.setString(2, board.getWriter());
			pstmt.setString(3, board.getContent());
			pstmt.setInt(4, board.getBoardnum());
			
			cnt = pstmt.executeUpdate();

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			disConnect();
		}
		return cnt;
	}

	@Override
	public int deleteWrite(int boardNum) {
		
		int cnt = 0;
		
		try {
			conn = DBUtil2.getConnection();
			String sql = "DELETE jdbc_board WHERE board_no = ?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, boardNum);

			cnt = pstmt.executeUpdate();

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			disConnect();
		}
		return cnt;
	}

	private void disConnect() {
		if (pstmt != null)
			try {
				pstmt.close();
			} catch (SQLException e) {
			}
		if (stmt != null)
			try {
				stmt.close();
			} catch (SQLException e) {
			}
		if (conn != null)
			try {
				conn.close();
			} catch (SQLException e) {
			}
		if (rs != null)
			try {
				rs.close();
			} catch (SQLException e) {
			}
	}

	@Override
	public List<BoardVO> search(BoardVO board) {
		
		List<BoardVO> searchList = new ArrayList<BoardVO>();
		try {
			conn = DBUtil.getConnection();
			String sql ="select * from jdbc_board where 1=1 ";
		
			if(board.getTitle() != null && !board.getTitle().equals("")) {
				sql += " and board_title = ?";
			}
			if(board.getWriter() != null && !board.getWriter().equals("")) {
				sql += " and board_writer = ?";
			}
			if(board.getContent() != null && !board.getContent().equals("")) {
				sql += " and board_content like '%' || ? || '%' "; // ||문자열결함
			}
			pstmt = conn.prepareStatement(sql);
			
			int index =1;
			
			if(board.getTitle() != null && !board.getTitle().equals("")) {
				pstmt.setString(index++, board.getTitle());
			}
			if(board.getWriter() != null && !board.getWriter().equals("")) {
				pstmt.setString(index++, board.getWriter());
			}
			if(board.getContent() != null && !board.getContent().equals(""))  {
				pstmt.setString(index++, board.getContent());
			}
			
			rs = pstmt.executeQuery();
			
			while(rs.next()) {
				//vo에 담아서 add시켜줘야한다.
				BoardVO temp = new BoardVO();
				temp.setBoardnum(rs.getInt("board_no"));
				temp.setTitle(rs.getString("board_title"));
				temp.setDate(rs.getDate("board_date"));
				temp.setWriter(rs.getString("board_writer"));
				temp.setContent(rs.getString("board_content"));
				
				searchList.add(temp);
				
			}
		}catch(SQLException e) {
			e.printStackTrace();
		}finally{
			disConnect();
		}
		
		return searchList;
	}

}