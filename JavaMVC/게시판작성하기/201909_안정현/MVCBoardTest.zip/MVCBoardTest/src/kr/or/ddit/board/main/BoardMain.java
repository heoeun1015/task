package kr.or.ddit.board.main;

import java.sql.Date;
import java.util.List;
import java.util.Scanner;

import org.apache.log4j.Logger;

import kr.or.ddit.board.service.BoardServiceImpl;
import kr.or.ddit.board.vo.BoardVO;

public class BoardMain {
	private Scanner scan = new Scanner(System.in);

	private BoardServiceImpl service;

	public BoardMain() {
		service = BoardServiceImpl.getInstance();
	}
	

	public static void main(String[] args) {
		new BoardMain().display();
	}

	public void display() {
		int n;
		do {
			System.out.println("*******************************************");
			System.out.println("어떤 업무를 하시겠습니까?");
			System.out.println("1.전체목록 출력  2.새글작성 3.수정 4.삭제 5.검색 6.종료");
			System.out.println("*******************************************");
			System.out.println("메뉴선택 =>");
			n = scan.nextInt();
			switch (n) {
			case 1:
				displayAll();
				break;
			case 2:
				newWrite();
				break;
			case 3:
				modifyWrite();
				break;
			case 4:
				deleteWrite();
				break;
			case 5:
				search();
				break;
			case 6:
				System.out.println("종료되었습니다.");
				return;
			default:
				System.out.println("다시입력해주세요");
			}
		} while (n != 6);
	}

	/*
	 * 글 수정 메서드
	 */
	private void modifyWrite() {
		System.out.println();
		System.out.println("-----------------------------------------------");
		System.out.println("수정할 게시물 번호를 입력해주세요");
		int boardNum = scan.nextInt();
		System.out.println("제목을 입력해 주세요");
		scan.nextLine();
		String title = scan.nextLine();
		System.out.println("작성자를 입력해 주세요");
		String writer = scan.nextLine();
		System.out.println("내용을 입력해 주세요");
		String content = scan.nextLine();
		System.out.println("-----------------------------------------------");
		BoardVO board = new BoardVO();
		board.setBoardnum(boardNum);
		board.setTitle(title);
		board.setWriter(writer);
		board.setContent(writer);

		int cnt = service.modifyWrite(board);

		if (cnt > 0) {
			System.out.println(boardNum + "번 게시글 수정 성공");
		} else {
			System.out.println(boardNum + "번 게시글 수정 실패");
		}

	}

	/*
	 * 글 검색 메서드
	 */
	private void search() {
		scan.nextLine(); // 입력버퍼 비우기
		System.out.println();
		System.out.println("검색할 정보를 입력하세요.");
		System.out.print("작성자 >>");
		String writer = scan.nextLine().trim(); // 좌우공백제거

		System.out.print("공지 제목 >>");
		String title = scan.nextLine().trim();

		System.out.print("공지 내용 >>");
		String content = scan.nextLine().trim();

		BoardVO bd = new BoardVO();
		bd.setWriter(writer);
		bd.setTitle(title);
		bd.setContent(content);
		
		List<BoardVO> searchList = service.search(bd);

		System.out.println("-----------------------------");

		if (searchList == null || searchList.size() == 0) {// 데이터가 없다면
			System.out.println("검색한 자료가 없습니다.");
		} else {
			for (BoardVO bd2 :searchList) {
				System.out.println("번호 : " + bd2.getBoardnum());
				System.out.println("작성자 : " + bd2.getWriter());
				System.out.println("제목 : " + bd2.getTitle());
				System.out.println("작성일자 : " + bd2.getDate());
				System.out.println("내용 : " + bd2.getContent());
				System.out.println("-------------------------------------");
			}
		}

		System.out.println("-----------------------------");
		System.out.println("출력작업 끝");

	}

	/*
	 * 글삭제 메서드
	 */
	private void deleteWrite() {
		System.out.println();
		System.out.println("삭제할 글 번호를 입력해주세요");
		System.out.println("-----------------------------------------------");
		int boardNum = scan.nextInt();
		int cnt = service.deleteWrite(boardNum);

		if (cnt > 0) {
			System.out.println(boardNum + "번 게시글 삭제 성공");
		} else {
			System.out.println(boardNum + "번 게시글 삭제 실패");
		}
	}
	
	/*
	 * 새글작성 메서드
	 */
	private void newWrite() {
		System.out.println();
		System.out.println("제목을 입력해 주세요");
		String title = scan.next();
		System.out.println("작성자를 입력해 주세요");
		String writer = scan.next();
		System.out.println("내용을 입력해 주세요");
		String content = scan.next();
		scan.nextLine();
		System.out.println("-----------------------------------------------");
		BoardVO board = new BoardVO();
		board.setTitle(title);
		board.setWriter(writer);
		board.setContent(content);

		int cnt = service.newWrite(board);

		if (cnt > 0) {
			System.out.println(title + "작성 성공");
		} else {
			System.out.println(title + "작성 실패");
		}
		System.out.println("-----------------------------------------------");

	}

	private void displayAll() {
		System.out.println();
		System.out.println("-------------------------------------");

		List<BoardVO> allList = service.displayAll();

		for (BoardVO temp : allList) {
			System.out.println("번호 : " + temp.getBoardnum());
			System.out.println("작성자 : " + temp.getWriter());
			System.out.println("제목 : " + temp.getTitle());
			System.out.println("작성일자 : " + temp.getDate());
			System.out.println("내용 : " + temp.getContent());
			System.out.println("-------------------------------------");
		}
	}

}
