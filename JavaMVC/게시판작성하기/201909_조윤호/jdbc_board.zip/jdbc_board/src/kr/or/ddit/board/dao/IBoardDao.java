package kr.or.ddit.board.dao;

import java.util.List;

import kr.or.ddit.board.vo.boardVO;


public interface IBoardDao {

	public int insertBoard(boardVO bv);

	public int deleteBoard(String boardNo);
	
	public int updateBoard(boardVO bv);
	
	public List<boardVO> getAllboardList();

	public List<boardVO> getSearchBoard(boardVO bv);

	public boolean getBoard(String boardNo);
	
}
