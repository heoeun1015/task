package kr.or.ddit.basic;

import java.util.List;
import java.util.Scanner;

import kr.or.ddit.board.service.boardServiceImpl;
import kr.or.ddit.board.service.IboardService;
import kr.or.ddit.board.vo.boardVO;



public class boardMain {
	

	private IboardService service;
	
	private Scanner scan = new Scanner(System.in); 
	
	public boardMain() {
		service = new boardServiceImpl();
	}
	

	public void displayMenu(){
		System.out.println();
		System.out.println("----------------------");
		System.out.println("  === 작 업 선 택 ===");
		System.out.println("  1. 게시판작성");
		System.out.println("  2. 게시판 삭제");
		System.out.println("  3. 게시판 수정");
		System.out.println("  4. 전체 목록 출력");
		System.out.println("  5. 게시판 검색");
		System.out.println("  0. 작업 끝.");
		System.out.println("----------------------");
		System.out.print("작업 선택 >> ");
	}
	
	
	public void start(){
		int choice;
		do{
			displayMenu(); 
			choice = scan.nextInt(); 
			switch(choice){
				case 1 : 
					insertBoard();
					break;
				case 2 : 
					deleteBoard();
					break;
				case 3 : 
					updateBoard();
					break;
				case 4 :  
					displayBoardAll();
					break;
				case 5 :  
					searchBoard();
					break;
				case 0 :  
					System.out.println("작업을 마칩니다.");
					break;
				default :
					System.out.println("번호를 잘못 입력했습니다. 다시입력하세요");
			}
		}while(choice!=0);
	}
	

	private void insertBoard() {
		boolean chk = false;

		System.out.print("제목>> ");
		String boardTitle = scan.next();
		System.out.print("작성자>> ");
		String boardWriter = scan.next();

		scan.nextLine(); // 입력버퍼 비우기

		System.out.print("내용>> ");
		String boardContent = scan.nextLine();

		boardVO bv = new boardVO();
		bv.setBoard_title(boardTitle);
		bv.setBoard_writer(boardWriter);
		bv.setBoard_content(boardContent);
		
		int cnt = service.insertBoard(bv);
		
		if (cnt > 0) {
			System.out.println("게시글 추가 작업 성공");
		} else {
			System.out.println("게시글 추가 작업 실패!");
		}
		
	}
	
	
	// 삭제
	private void deleteBoard() {
		String boardNo = "";
		boolean chk = true;

		do {
			System.out.println();
			System.out.print("삭제할 번호를 입력하세요>>");
			boardNo = scan.next();

			chk = service.getBoard(boardNo);
			if (!chk) {
				System.out.println(boardNo + "번 글은 없은 게시글입니다.");
				System.out.println("삭제할 자료가 없으니 다시 입력하세요.");
			}

		} while (!chk);
		
		int cnt = service.deleteBoard(boardNo);

		if (cnt > 0) {
			System.out.println(boardNo + "번 글 삭제 성공..");
		} else {
			System.out.println(boardNo + "번 글 삭제 실패!");
		}

	}
	

	private void updateBoard() {
		String boardNo = "";
		boolean chk = true;

		do {
			System.out.println();
			System.out.print("수정할 게시글의 번호를 입력하세요>>");
			boardNo = scan.next();

			chk = service.getBoard(boardNo);
			if (!chk) {
				System.out.println(boardNo + "번 글은 없은 게시글입니다.");
				System.out.println("수정할 자료가 없으니 다시 입력하세요.");
			}

		} while (!chk);

		System.out.println("수정할 내용을 입력하세요.");
		System.out.print("제목>> ");
		String boardTitle = scan.next();
		System.out.print("작성자>> ");
		String boardWriter = scan.next();
		scan.nextLine(); // 입력버퍼 비우기
		System.out.print("내용>> ");
		String boardContent = scan.nextLine();

		boardVO bv = new boardVO();
		bv.setBoard_no(boardNo);
		bv.setBoard_title(boardTitle);
		bv.setBoard_writer(boardWriter);
		bv.setBoard_content(boardContent);
		
		int cnt = service.updateBoard(bv);

		if (cnt > 0) {
			System.out.println(boardNo + "번 게시글 정보를 수정했습니다.");
		} else {
			System.out.println(boardNo + "번 게시글의 정보 수정 실패!");
		}


	}


	private void displayBoardAll() {
		System.out.println();
		System.out.println("---------------------------------------------------------");
		System.out.println(" 번    호\t제    목\t작 성 자\t작성날짜\t\t\t내    용");
		System.out.println("---------------------------------------------------------");

		List<boardVO> boardList =  service.getAllboardList();
		
		for(boardVO bv : boardList) {
			System.out.println(bv.getBoard_no() + "\t" + bv.getBoard_title() + "\t" + bv.getBoard_writer() + "\t" + bv.getBoard_date() + "\t" + bv.getBoard_content());
		}
		
		System.out.println("---------------------------------------------------------");
		System.out.println("출력작업 끝...");
	}


	private void searchBoard() {
		System.out.println();

		String boardNo = "";
		boolean chk = true;

		do {
			System.out.print("검색할 게시글의 번호를 입력하세요>>");
			boardNo = scan.next();

			chk = service.getBoard(boardNo);
			if (chk == false) {
				System.out.println(boardNo + "번 글은 없은 게시글입니다.");
				System.out.println("검색할 자료가 없으니 다시 입력하세요.");
			}

		} while (chk == false);

		boardVO bv = new boardVO();
		bv.setBoard_no(boardNo);
		
		System.out.println("---------------------------------------------------------");
		System.out.println(" 번    호\t제    목\t작 성 자\t작성날짜\t\t\t내    용");
		System.out.println("---------------------------------------------------------");

		List<boardVO> boardList =  service.getSearchBoard(bv);
		
		for(boardVO b : boardList) {
			System.out.println(b.getBoard_no() + "\t" + b.getBoard_title() + "\t" + b.getBoard_writer() + "\t" + b.getBoard_date() + "\t" + b.getBoard_content());
		}
		
		System.out.println("---------------------------------------------------------");
		
	}
	

	
	
	public static void main(String[] args) {
		boardMain boardObj = new boardMain();
		boardObj.start();
	}
	
	
}
