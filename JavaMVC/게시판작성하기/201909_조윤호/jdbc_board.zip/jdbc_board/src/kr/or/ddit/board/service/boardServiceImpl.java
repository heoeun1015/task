package kr.or.ddit.board.service;

import java.util.List;


import kr.or.ddit.board.dao.boardDaoImpl;
import kr.or.ddit.board.dao.IBoardDao;
import kr.or.ddit.board.vo.boardVO;

public class boardServiceImpl implements IboardService {

	private IBoardDao boardDao;
	
	public boardServiceImpl() {
		boardDao = new boardDaoImpl();
	}
	
	@Override
	public int insertBoard(boardVO bv) {
		return boardDao.insertBoard(bv);
	}

	@Override
	public int deleteBoard(String boardNo) {
		return boardDao.deleteBoard(boardNo);
	}

	@Override
	public int updateBoard(boardVO bv) {
		return boardDao.updateBoard(bv);
	}

	@Override
	public List<boardVO> getAllboardList() {
		return boardDao.getAllboardList();
	}

	@Override
	public List<boardVO> getSearchBoard(boardVO bv) {
		return boardDao.getSearchBoard(bv);
	}

	@Override
	public boolean getBoard(String boardNo) {
		return boardDao.getBoard(boardNo);
	}

}
