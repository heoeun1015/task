package kr.or.ddit.board.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import kr.or.ddit.board.vo.BoardVO;
import kr.or.ddit.util.DBUtil;

public class BoardDaoImpl implements IBoardDao {

	private Connection conn;
	private Statement stmt;
	private PreparedStatement pstmt;
	private ResultSet rs;
	
	/**
	 * 자원반납
	 */
	private void disConnect() {
		if(rs!=null) try {rs.close();}catch(SQLException e) {}
		if(pstmt!=null) try {pstmt.close();}catch(SQLException e) {}
		if(stmt!=null) try {stmt.close();}catch(SQLException e) {}
		if(conn!=null) try {conn.close();}catch(SQLException e) {}
	}
	
	@Override
	public int insertBoard(BoardVO bv) {
		int cnt = 0;
		
		try {
			conn = DBUtil.getConnection();
			
			String sql = "insert into jdbc_board "
//						+ "board_no, board_title, board_writer, board_date, board_content "
						+ "values (board_seq.nextval,?,?,sysdate,?)";
			
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, bv.getBoard_title());
			pstmt.setString(2, bv.getBoard_writer());
			pstmt.setString(3, bv.getBoard_content());
			
			cnt = pstmt.executeUpdate();
			
		}catch(SQLException e) {
			e.printStackTrace();
		}finally {
			disConnect();
		}
		return cnt;
	}

	@Override
	public boolean getBoard(String boardNo) {
		boolean chk = false;
		try {
			conn = DBUtil.getConnection();
			String sql = "select count(*) cnt from jdbc_board " + "where board_no = ?";
			
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, boardNo);
			
			rs = pstmt.executeQuery();
			
			int cnt = 0;
			if(rs.next()) {
				cnt = rs.getInt("cnt");
			}
			if(cnt > 0) {
				chk = true;
			}
		}catch(SQLException e) {
			e.printStackTrace();
		}finally {
			disConnect();
		}
		return chk;
	}
	
	@Override
	public List<BoardVO> getAllBoardList() {
		
		List<BoardVO> boardList = new ArrayList<BoardVO>();
		
		try {
			conn = DBUtil.getConnection();
			
			String sql = "select * from jdbc_board";
			
			stmt = conn.createStatement();
			
			rs = stmt.executeQuery(sql);
			
			while(rs.next()) {
				BoardVO bv = new BoardVO();
				
				bv.setBoard_no(rs.getString("board_no"));
				bv.setBoard_title(rs.getString("board_title"));
				bv.setBoard_writer(rs.getString("board_writer"));
				bv.setBoard_date(rs.getString("board_date"));
				bv.setBoard_content(rs.getString("board_content"));
				
				boardList.add(bv);
			}
		}catch(SQLException e) {
			e.printStackTrace();
		}finally {
			disConnect();
		}
		return boardList;
	}

	@Override
	public int updateBoard(BoardVO bv) {
		int cnt = 0;
		
		try {
			conn = DBUtil.getConnection();
					
			String sql = "update jdbc_board " + "set board_title = ? " 
											+ " ,board_content = ? " 
											+ "where board_no = ?";
			
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, bv.getBoard_title());
			pstmt.setString(2, bv.getBoard_content());
			pstmt.setString(3, bv.getBoard_no());
			
			cnt = pstmt.executeUpdate();
			
		}catch(SQLException e) {
			e.printStackTrace();
		}finally {
			disConnect();
		}
		return cnt;
	}

	@Override
	public int deleteBoard(String boardNo) {
		int cnt = 0;
		
		try {
			conn = DBUtil.getConnection();
			String sql = "delete from jdbc_board where board_no = ?";
			
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, boardNo);
			
			cnt = pstmt.executeUpdate();
			
		}catch(SQLException e) {
			e.printStackTrace();
		}finally {
			disConnect();
		}		
		return cnt;
	}

	@Override
	public List<BoardVO> getSearchBoard(BoardVO bv) {
		List<BoardVO> boardList = new ArrayList<BoardVO>();
		
		try {
			conn = DBUtil.getConnection();
			String sql = "select * from jdbc_board where 1=1";	
			
			if(bv.getBoard_no() != null && !bv.getBoard_no().equals("")) {
				sql += "and board_no = ?";
			}
			if(bv.getBoard_title() != null && !bv.getBoard_title().equals("")) {
				sql += "and board_title = ?";
			}
			if(bv.getBoard_writer() != null && !bv.getBoard_writer().equals("")) {
				sql += "and board_writer = ?";
			}
			if(bv.getBoard_date() != null && !bv.getBoard_date().equals("")) {
				sql += "and board_date = ?";
			}
			if(bv.getBoard_content() != null && !bv.getBoard_content().equals("")) {
				sql += "and board_content like '%' || ? || '%'"  ;
			}
			pstmt = conn.prepareStatement(sql);
			int index = 1;
			
			if(bv.getBoard_no() != null && !bv.getBoard_no().equals("")) {
				pstmt.setString(index++, bv.getBoard_no());
			}
			if(bv.getBoard_title() != null && !bv.getBoard_title().equals("")) {
				pstmt.setString(index++, bv.getBoard_title());
			}
			if(bv.getBoard_writer() != null && !bv.getBoard_writer().equals("")) {
				pstmt.setString(index++, bv.getBoard_writer());
			}
			if(bv.getBoard_date() != null && !bv.getBoard_date().equals("")) {
				pstmt.setString(index++, bv.getBoard_date());
			}
			if(bv.getBoard_content() != null && !bv.getBoard_content().equals("")) {
				pstmt.setString(index++, bv.getBoard_content());
			}
			
			rs = pstmt.executeQuery();
			
			while(rs.next()) {
				BoardVO bv2 = new BoardVO();
				bv2.setBoard_no(rs.getString("board_no"));
				bv2.setBoard_title(rs.getString("board_title"));
				bv2.setBoard_writer(rs.getString("board_writer"));
				bv2.setBoard_date(rs.getString("board_date"));
				bv2.setBoard_content(rs.getString("board_content"));
				
				boardList.add(bv2);
			}
			
			
		}catch(SQLException e) {
			e.printStackTrace();
		}finally {
			disConnect();
		}
		return boardList;
	}


}
