package kr.or.ddit.member.service;

import java.util.List;

import kr.or.ddit.member.dao.IMemberDao;
import kr.or.ddit.member.dao.MemberDaoImpl;
import kr.or.ddit.member.vo.MemberVO;

public class MemberServiceImple implements IMemberService {

	//사용할 DAO의 객체변수를 선언한다.
	private IMemberDao memDao;
//	private MemberDaoImpl memDao;			//둘 다 가능
	
	public MemberServiceImple() {	//생성자
		
		memDao = new MemberDaoImpl();
	}
	
	@Override
	public int writeMember(MemberVO mv) {
		
		return memDao.writeMember(mv);
	}

	@Override
	public boolean getNum(String memNo) {
		
		return memDao.getNum(memNo);
	}
	
/*	@Override
	public boolean getTitle(String memTitle) {
		
		return memDao.getTitle(memTitle);
	}
*/
	@Override
	public List<MemberVO> getAllMemberList() {
		
		return memDao.getAllMemberList();
	}

	@Override
	public int updateMember(MemberVO mv) {
		
		return memDao.updateMember(mv);
	}

	@Override
	public int deleteMember(String memNo) {

		return memDao.deleteMember(memNo);
	}

	@Override
	public List<MemberVO> getSearchMember(MemberVO mv) {

		return memDao.getSearchMember(mv);
	}

}
