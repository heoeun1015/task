package kr.or.ddit.member.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import kr.or.ddit.member.vo.MemberVO;
import kr.or.ddit.util.DBUtil;
import kr.or.ddit.util.DBUtil3;

public class MemberDaoImpl implements IMemberDao {

	private Connection conn;
	private Statement stmt;
	private PreparedStatement pstmt;
	private ResultSet rs;
	
	/**
	 * 자원반납
	 */
	private void disConnect() {
		//  사용했던 자원 반납
		if(rs!=null)try{ rs.close(); }catch(SQLException e){}
		if(pstmt!=null)try{ pstmt.close(); }catch(SQLException e){}
		if(stmt!=null)try{ stmt.close(); }catch(SQLException e){}
		if(conn!=null)try{ conn.close(); }catch(SQLException e){}
	}
	
	
	@Override
	public List<MemberVO> getAllMemberList() {
		
		List<MemberVO> memList = new ArrayList<MemberVO>();
		
		try {
			conn = DBUtil.getConnection();
			
			String sql = "select * from jdbc_board";
			
			stmt = conn.createStatement();
			
			rs = stmt.executeQuery(sql);
			
			while(rs.next()) {
				MemberVO mv = new MemberVO();
				
				mv.setBOARD_NO(rs.getString("BOARD_NO"));
				mv.setBOARD_TITLE(rs.getString("BOARD_TITLE"));
				mv.setBOARD_WRITER(rs.getString("BOARD_WRITER"));
				mv.setBOARD_DATE(rs.getString("BOARD_DATE"));
				mv.setBOARD_CONTENT(rs.getString("BOARD_CONTENT"));
			
				memList.add(mv);
			}
		}catch (SQLException e) {
			e.printStackTrace();
		}finally {
			disConnect();
		}
		return memList;
	}

	
	@Override
	public int writeMember(MemberVO mv) {
		
		int cnt = 0;
		
		try {
			
			conn = DBUtil.getConnection();
			//conn = DBUtil2.getConnection();
			//conn = DBUtil3.getConnection();
			
			String sql = "INSERT INTO jdbc_board"
					+ 	"(BOARD_NO, BOARD_TITLE, BOARD_WRITER, BOARD_DATE, BOARD_CONTENT) "
					+ 	" VALUES (board_seq.nextval, ?, ?, SYSDATE , ?) ";
			
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, mv.getBOARD_TITLE());
			pstmt.setString(2, mv.getBOARD_WRITER());
			pstmt.setString(3, mv.getBOARD_CONTENT());
		
			cnt = pstmt.executeUpdate();	//executeUpdate는 int값
			
		}catch (SQLException e) {
			System.out.println("게시글 추가 작업 실패~");
			e.printStackTrace();
		}finally {	
			disConnect(); 
		}
		return cnt;
	}
	
	//글번호 이용하여 글이 있는지 알려주는
	@Override
	public boolean getNum(String memNo) {
		
		boolean chk = false;
		
		try {
			conn = DBUtil.getConnection();
			String sql = "select count(*) cnt from jdbc_board "
						+ "where BOARD_NO = ? ";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, memNo);
			
			rs = pstmt.executeQuery();		//executeQuery는 resultset을 리턴
			
			int cnt = 0;  
			if(rs.next()) {
				cnt = rs.getInt("cnt");
			}
			
			if(cnt>0) {
				chk = true;
			}
			
		}catch (SQLException e) {
			e.printStackTrace();
		}finally {
			disConnect();
		}
		return chk;
	}
/*	
	//글제목을 이용하여 글이있는지 확인
	@Override
	public boolean getTitle(String memTitle) {
		
		boolean chk = false;
		
		try {
			conn = DBUtil.getConnection();
			String sql = "select count(*) cnt from jdbc_board "
						+ "where BOARD_TITLE = ? ";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, memTitle);
			
			rs = pstmt.executeQuery();		//executeQuery는 resultset을 리턴
			
			int cnt = 0;  
			if(rs.next()) {
				cnt = rs.getInt("cnt");
			}
			
			if(cnt>0) {
				chk = true;
			}
			
		}catch (SQLException e) {
			e.printStackTrace();
		}finally {
			disConnect();
		}
		return chk;
	}
*/
	//글을 수정
	@Override
	public int updateMember(MemberVO mv) {
		
		int cnt = 0;
		
		try {
			conn = DBUtil.getConnection();
			
			String sql = "UPDATE jdbc_board "
						+ "SET BOARD_TITLE = ? "
						  + ", BOARD_DATE = SYSDATE "
						  + ", BOARD_CONTENT = ? "
						  + ", BOARD_WRITER = ? "
						  + "WHERE BOARD_NO = ? ";
			
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, mv.getBOARD_TITLE());
			pstmt.setString(2, mv.getBOARD_CONTENT());
			pstmt.setString(3, mv.getBOARD_WRITER());
			pstmt.setString(4, mv.getBOARD_NO());
			
			cnt = pstmt.executeUpdate();
			
		}catch (SQLException e) {
			e.printStackTrace();
		}finally {
			disConnect();
		}
		return cnt;
	}

	//글을 삭제
	@Override
	public int deleteMember(String memNo) {
		
		int cnt = 0;
		
		try {
			conn = DBUtil.getConnection();
			String sql = "DELETE FROM jdbc_board WHERE BOARD_NO=? ";
			
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, memNo);
			
			cnt = pstmt.executeUpdate();
			
		}catch (SQLException e) {
			e.printStackTrace();
		}finally {
			disConnect();
		}
		return cnt;
	}

	//글검색
	@Override
	public List<MemberVO> getSearchMember(MemberVO mv) {
		
		List<MemberVO> memList = new ArrayList<MemberVO>();
		
		try {
			conn = DBUtil.getConnection();
			
			String sql = "SELECT * FROM jdbc_board WHERE 1=1 ";	
			//아무의미없는 1=1조건을 붙여서 뒤에 오는 조건들에 and붙여질수있게함
			
			if(mv.getBOARD_NO() != null && !mv.getBOARD_NO().equals("")) {
				sql += " and BOARD_NO = ? ";
			}
			
			if(mv.getBOARD_TITLE() != null && !mv.getBOARD_TITLE().equals("")) {
				sql += " and BOARD_TITLE = ? ";
			}
			
			if(mv.getBOARD_WRITER() != null && !mv.getBOARD_WRITER().equals("")) {
				sql += " and BOARD_WRITER = ? ";
			}
			
			if(mv.getBOARD_CONTENT() != null && !mv.getBOARD_CONTENT().equals("")) {
				sql += " and BOARD_CONTENT Like '%' || ? || '%' ";
			}
			
			pstmt = conn.prepareStatement(sql);
			
			int index = 1;
			if(mv.getBOARD_NO() != null && !mv.getBOARD_NO().equals("")) {
				pstmt.setString(index++, mv.getBOARD_NO());
			}
			if(mv.getBOARD_TITLE() != null && !mv.getBOARD_TITLE().equals("")) {
				pstmt.setString(index++, mv.getBOARD_TITLE());
			}
			if(mv.getBOARD_WRITER() != null && !mv.getBOARD_WRITER().equals("")) {
				pstmt.setString(index++, mv.getBOARD_WRITER());
			}
			if(mv.getBOARD_CONTENT() != null && !mv.getBOARD_CONTENT().equals("")) {
				pstmt.setString(index++, mv.getBOARD_CONTENT());
			}
			
			rs = pstmt.executeQuery();
			
			while(rs.next()) {
				MemberVO mv2 = new MemberVO();
				mv2.setBOARD_NO(rs.getString("BOARD_NO"));
				mv2.setBOARD_TITLE(rs.getString("BOARD_TITLE"));
				mv2.setBOARD_WRITER(rs.getString("BOARD_WRITER"));
				mv2.setBOARD_DATE(rs.getString("BOARD_DATE"));
				mv2.setBOARD_CONTENT(rs.getString("BOARD_CONTENT"));
			
				memList.add(mv2);
			}
			
		}catch (SQLException e) {
			e.printStackTrace();
		}finally {
			disConnect();
		}
		return memList;
	}

}
