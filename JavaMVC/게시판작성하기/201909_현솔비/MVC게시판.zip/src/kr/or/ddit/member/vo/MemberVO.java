package kr.or.ddit.member.vo;
/**
 * DB 테이블에 있는 컬럼을 기준으로 데이터를 객체화한 클래스
 * @author pc20
 *<p>
 *	DB테이블의 '컬럼'이 이 클래스의 '멤버변수'가 된다. <br>
 *	DB테이블의 컬럼과 클래스의 멤버변수를 매핑하는 역할을 수행한다.<br>
 *</p>
 * 
 */
public class MemberVO {
	private String BOARD_NO;
	private String BOARD_TITLE;
	private String BOARD_WRITER;
	private String BOARD_DATE;
	private String BOARD_CONTENT;
	
	public String getBOARD_NO() {
		return BOARD_NO;
	}
	public void setBOARD_NO(String bOARD_NO) {
		this.BOARD_NO = bOARD_NO;
	}
	public String getBOARD_TITLE() {
		return BOARD_TITLE;
	}
	public void setBOARD_TITLE(String bOARD_TITLE) {
		this.BOARD_TITLE = bOARD_TITLE;
	}
	public String getBOARD_WRITER() {
		return BOARD_WRITER;
	}
	public void setBOARD_WRITER(String bOARD_WRITER) {
		this.BOARD_WRITER = bOARD_WRITER;
	}
	public String getBOARD_DATE() {
		return BOARD_DATE;
	}
	public void setBOARD_DATE(String bOARD_DATE) {
		this.BOARD_DATE = bOARD_DATE;
	}
	public String getBOARD_CONTENT() {
		return BOARD_CONTENT;
	}
	public void setBOARD_CONTENT(String bOARD_CONTENT) {
		this.BOARD_CONTENT = bOARD_CONTENT;
	}
	
	
	@Override
	public String toString() {
		return "MemberVO [BOARD_NO=" + BOARD_NO 
					 + ", BOARD_TITLE = " + BOARD_TITLE
					 + ", BOARD_WRITER = " + BOARD_WRITER  
					 + ", BOARD_DATE = " + BOARD_DATE
				   	 + ", BOARD_CONTENT = " + BOARD_CONTENT + "]";
	}
}
