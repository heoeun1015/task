package kr.or.ddit.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import kr.or.ddit.util.DBUtil3;
import kr.or.ddit.vo.MVCBoardVO;

public class MVCBoardDaoImpl implements IBoardDao{
	private Connection conn;
	private Statement stmt;
	private PreparedStatement pstmt;
	private ResultSet rs;

	private static MVCBoardDaoImpl instance;
	
	private MVCBoardDaoImpl() {};
	
	public static MVCBoardDaoImpl getInstance()
	{
		if(instance == null)
		{
			instance = new MVCBoardDaoImpl();
		}
		
		return instance;
	}
	
	private void disConnect() {
		if(rs!=null) try {rs.close();} catch (SQLException e) {};
		if(stmt!=null) try {stmt.close();} catch (SQLException e) {};
		if(pstmt!=null) try {pstmt.close();} catch (SQLException e) {};
		if(conn!=null) try {conn.close();} catch (SQLException e) {};
	}

	@Override
	public MVCBoardVO getSearchList(int number) {
		MVCBoardVO mv = new MVCBoardVO();
		
		try {
			conn = DBUtil3.getConnection();
			String sql = "SELECT * FROM jdbc_board WHERE board_no = ?";
			
			pstmt = conn.prepareStatement(sql);
			
			pstmt.setInt(1, number);
			
			rs = pstmt.executeQuery();
			
			rs.next();
			
			mv.setBoard_no(rs.getInt("board_no"));
			mv.setBoard_title(rs.getString("board_title"));
			mv.setBoard_writer(rs.getString("board_writer"));
			mv.setBoard_date(rs.getDate("board_date"));
			mv.setBoard_content(rs.getString("board_content"));
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			disConnect();
		}
		
		return mv;
	}

	@Override
	public int getDeleteList(int number) {
		int cnt=0;
		
		try {
			conn = DBUtil3.getConnection();
			String sql = "DELETE FROM jdbc_board WHERE board_no = ?";
			
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, number);
			
			cnt = pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			disConnect();
		}

		return cnt;
	}

	@Override
	public int getUpdateList(MVCBoardVO mv) {
		int cnt=0;
		
		try {
			conn = DBUtil3.getConnection();
			
			String sql = "UPDATE jdbc_board SET board_title = ?, "
					+ "board_writer = ?, board_date = sysdate, "
					+ "board_content = ? WHERE board_no = ?";
			
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, mv.getBoard_title());
			pstmt.setString(2, mv.getBoard_writer());
			pstmt.setString(3, mv.getBoard_content());
			pstmt.setInt(4, mv.getBoard_no());
			
			cnt = pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			disConnect();
		}
		return cnt;
	}

	@Override
	public List<MVCBoardVO> getViewAll() {
		List<MVCBoardVO> boardList = new ArrayList<MVCBoardVO>();
		
		try {
			conn = DBUtil3.getConnection();
			
			String sql = "SELECT * FROM jdbc_board";
			
			stmt = conn.createStatement();
			
			rs = stmt.executeQuery(sql);
			
			while(rs.next()) {
				MVCBoardVO mv = new MVCBoardVO();
				
				mv.setBoard_no(rs.getInt("board_no"));
				mv.setBoard_title(rs.getString("board_title"));
				mv.setBoard_writer(rs.getString("board_writer"));
				mv.setBoard_date(rs.getDate("board_date"));
				mv.setBoard_content(rs.getString("board_content"));
				
				boardList.add(mv);
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			disConnect();
		}
		return boardList;
	}

	@Override
	public int getWriteList(MVCBoardVO mv) {
		int cnt=0;
		try {
			conn = DBUtil3.getConnection();
			
			String sql = "INSERT INTO jdbc_board (board_no, board_title, "
					+ "board_writer, board_date, board_content) VALUES "
					+ "(board_seq.nextVal, ?, ?, sysdate, ?)";
			
			pstmt = conn.prepareStatement(sql);
			
			pstmt.setString(1, mv.getBoard_title());
			pstmt.setString(2, mv.getBoard_writer());
			pstmt.setString(3, mv.getBoard_content());
			
			cnt = pstmt.executeUpdate();
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			disConnect();
		}
		return cnt;
	}
}
