package kr.or.ddit.member.service;

import java.util.List;

import kr.or.ddit.member.dao.IMemberDao;
import kr.or.ddit.member.dao.MemberdaoImpl;
import kr.or.ddit.member.vo.MemberVo;

public class MemberServiceImpl implements IMemberService {
	
	// 사용할 DAO의 객체변수를 선언한다.
	private IMemberDao memDao;
	
	
	public MemberServiceImpl() {
		memDao = new MemberdaoImpl();
	}
	
	
	
	
	
	@Override
	public int insertMember(MemberVo mv) {
		/*int cnt =  memDao.insertMember(mv);
		
		if(cnt>0) {
			//메일전송객체.sendMail(mv.getMem_id());
			// 기능을 여기(serviceimpl)에 구현하면됨.
			// Dao와 관련없는 건 service에서 처리함
		}
		//return cnt;*/
		
		
		return memDao.insertMember(mv);
	}

	
	@Override
	public boolean getMember(String memId) {
		
		return memDao.getMember(memId);
	}

	
	@Override
	public List<MemberVo> getAllMemberList() {
		
		return memDao.getAllMemberList();
	}

	
	@Override
	public int updateMember(MemberVo mv) {
		
		return memDao.updateMember(mv);
	}

	
	@Override
	public int deleteMember(String memId) {
		
		return memDao.deleteMember(memId);
	}

	
	@Override
	public List<MemberVo> getSearchMember(MemberVo mv) {
		
		return memDao.getSearchMember(mv);
	}

	
}
