package kr.or.ddit.board.service;

import java.util.List;

import kr.or.ddit.board.dao.BoardDaoImpl;
import kr.or.ddit.board.dao.IBoardDao;
import kr.or.ddit.board.vo.BoardVO;

public class BoardServiceImpl implements IBoardService {
	
	private IBoardDao boardDao;
	
	public BoardServiceImpl() {
		boardDao = new BoardDaoImpl();
	}
	@Override
	public int writePost(BoardVO bv) {
		
		return boardDao.writePost(bv);
	}

	@Override
	public List<BoardVO> displayPost() {
		return boardDao.displayPost();
	}

	@Override
	public int editPost(BoardVO bv) {
		return boardDao.editPost(bv);
	}

	@Override
	public int deletePost(String board_no) {
		return boardDao.deletePost(board_no);
	}

	@Override
	public List<BoardVO> getSearchBoard(BoardVO bv) {
		return boardDao.getSearchBoard(bv);
	}

}
