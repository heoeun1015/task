package board.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import board.vo.BoardVO;
import util.DBUtil3;

public class BoardDaoImpl implements IBoardDao {
	private Connection conn;
	private Statement stmt;
	private PreparedStatement pstmt;
	private ResultSet rs;
	
	//Log4j를 이용한 로그 남기기
	private static final Logger sqlLogger = Logger.getLogger("log4jexam.sql.Query");//쿼리 
	private static final Logger paramLogger = Logger.getLogger("log4jexam.sql.Parameter");//파라미터
	private static final Logger resultLogger = Logger.getLogger(BoardDaoImpl.class);

	
	/**
	 * 자원반납
	*/
	private void disConnect() {
		//사용했던 자원 반납
		if(rs != null) try {rs.close();} catch(SQLException e) {}
		if(pstmt != null) try {pstmt.close();} catch(SQLException e) {}
		if(stmt != null) try {stmt.close();} catch(SQLException e) {}
		if(conn != null) try {conn.close();} catch(SQLException e) {}
	}
	
	//새 게시글 작성
	@Override
	public int insertBoard(BoardVO bv) {
		int cnt = 0;
		
		try {
			conn = DBUtil3.getConnection();
			
			String sql = "INSERT INTO jdbc_board "
						+ " (board_title, board_writer, board_content, board_no, board_date) "
						+ " values (?, ?, ?, board_seq.nextval, SYSDATE) ";

			sqlLogger.debug("쿼리 : " + sql);

			
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, bv.getBoard_title());
			pstmt.setString(2, bv.getBoard_writer());
			pstmt.setString(3, bv.getBoard_content());
			
			paramLogger.debug("파라미터 : " + "(" 
					+ bv.getBoard_title() + ","
					+ bv.getBoard_writer() + ","
					+ bv.getBoard_content() + ")");
			
			cnt = pstmt.executeUpdate();
			
			resultLogger.debug("결과 : " + cnt);

			
		}catch(SQLException e) {
			e.printStackTrace();
		}finally {
			disConnect();
		}
		
		return cnt;
	}

	//작성자가 있는지 확인
	@Override
	public boolean getWriter(String boardWriter) {
		boolean check = false;
		
		try {
			conn = DBUtil3.getConnection();
			String sql = "select count(*) cnt from jdbc_board " + " where board_writer = ?";
			
			sqlLogger.debug("쿼리 : " + sql);

			
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, boardWriter);
			
			paramLogger.debug("파라미터 : " + "(" 
					+ boardWriter + ")");
			
			rs = pstmt.executeQuery();
			
			int cnt = 0;
			
			resultLogger.debug("결과 : " + cnt);

			if(rs.next()) {
				cnt = rs.getInt("cnt");
			}
			if(cnt > 0) {
				check = true;
			}
		}catch(SQLException e) {
			e.printStackTrace();
		}finally {
			disConnect();
		}
		
		return check;
	}

	//전체 게시글 출력
	@Override
	public List<BoardVO> getAllBoardList() {
		List<BoardVO> boardList = new ArrayList<BoardVO>();
		
		try {
			conn = DBUtil3.getConnection();
			
			String sql = "SELECT board_no, board_title, board_writer, TO_CHAR(TO_DATE(board_date, 'YY.MM.DD'), 'YY.MM.DD') board_date, board_content FROM jdbc_board";
					
			stmt = conn.createStatement();
			
			rs = stmt.executeQuery(sql);
			
						
			while(rs.next()) {
				BoardVO bv = new BoardVO();
				
				bv.setBoard_no(rs.getString("board_no"));
				bv.setBoard_title(rs.getString("board_title"));
				bv.setBoard_writer(rs.getString("board_writer"));
				bv.setBoard_date(rs.getString("board_date"));
				bv.setBoard_content(rs.getString("board_content"));
			
				boardList.add(bv);
			}
			
		}catch(SQLException e) {
			e.printStackTrace();
		}finally {
			disConnect();
		}
		
		return boardList;
	}

	//게시글 수정
	@Override
	public int updateBoard(BoardVO bv) {
		int cnt = 0;
		
		try {
			conn = DBUtil3.getConnection();
			
			String sql = "UPDATE jdbc_board "
						+"SET board_title = ? "
						+ "   , board_date = SYSDATE "
						+ "   , board_content = ? "
						+ "where board_writer = ? "
						+ "AND board_no = ? ";
			
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, bv.getBoard_title());
			pstmt.setString(2, bv.getBoard_content());
			pstmt.setString(3, bv.getBoard_writer());
			pstmt.setString(4, bv.getBoard_no());
	
			cnt = pstmt.executeUpdate();//데이터 업데이트 성공 횟수
			
		}catch(SQLException e) {
			e.printStackTrace();
		}finally {
			disConnect();
		}
		
		return cnt;
	}
	
	//게시글 수정 전 수정할 수 있는 글 목록 출력
	@Override
	public List<BoardVO> updateList(String boardWriter){
		List<BoardVO> boardList = new ArrayList<BoardVO>();
		
		try {
			conn = DBUtil3.getConnection();
			
			String sql = "SELECT board_no, board_title, board_writer, TO_CHAR(TO_DATE(board_date, 'YY.MM.DD'), 'YY.MM.DD') board_date, board_content FROM jdbc_board WHERE board_writer = ? ";
					
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, boardWriter);
			
			rs = pstmt.executeQuery();
				
			while(rs.next()) {
				BoardVO bv = new BoardVO();
				
				bv.setBoard_no(rs.getString("board_no"));
				bv.setBoard_title(rs.getString("board_title"));
				bv.setBoard_writer(rs.getString("board_writer"));
				bv.setBoard_date(rs.getString("board_date"));
				bv.setBoard_content(rs.getString("board_content"));
				
				boardList.add(bv);
			}
			
		}catch(SQLException e) {
			e.printStackTrace();
		}finally {
			disConnect();
		}
		
		return boardList;
	}
	

	//게시글 삭제
	@Override
	public int deleteBoard(String boardWriter, String num) {
		int cnt = 0;
		
		try {
			conn = DBUtil3.getConnection();
			String sql = "DELETE FROM jdbc_board WHERE board_writer = ? AND board_no = ? ";
			
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, boardWriter);
			pstmt.setString(2, num);
			
			cnt = pstmt.executeUpdate();
			
		}catch(SQLException e) {
			e.printStackTrace();
		}finally {
			disConnect();
		}
		
		return cnt;
	}

	//제목 검색
	@Override
	public List<BoardVO> getSearchTitle(String title) {
		List<BoardVO> boardList = new ArrayList<BoardVO>();
		
		try {
			conn = DBUtil3.getConnection();
			String sql = "select board_no, board_title, board_writer, TO_CHAR(TO_DATE(board_date, 'YY.MM.DD'), 'YY.MM.DD') board_date, board_content from jdbc_board " 
						+ " where board_title LIKE ? ";
			
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, title);
			
			rs = pstmt.executeQuery();
						
			while(rs.next()) {
				BoardVO bv = new BoardVO();
				
				bv.setBoard_no(rs.getString("board_no"));
				bv.setBoard_title(rs.getString("board_title"));
				bv.setBoard_writer(rs.getString("board_writer"));
				bv.setBoard_date(rs.getString("board_date"));
				bv.setBoard_content(rs.getString("board_content"));
			
				boardList.add(bv);
			}
			
		}catch(SQLException e) {
			e.printStackTrace();
		}finally {
			disConnect();
		}
		
		return boardList;
	}
	
	//내용 검색
	@Override
	public List<BoardVO> getSearchContent(String content) {
		List<BoardVO> boardList = new ArrayList<BoardVO>();
		
		try {
			conn = DBUtil3.getConnection();
			String sql = "select board_no, board_title, board_writer, TO_CHAR(TO_DATE(board_date, 'YY.MM.DD'), 'YY.MM.DD') board_date, board_content from jdbc_board " 
						+ " where board_content LIKE ? ";
			
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, content);
			
			rs = pstmt.executeQuery();
						
			while(rs.next()) {
				BoardVO bv = new BoardVO();
				
				bv.setBoard_no(rs.getString("board_no"));
				bv.setBoard_title(rs.getString("board_title"));
				bv.setBoard_writer(rs.getString("board_writer"));
				bv.setBoard_date(rs.getString("board_date"));
				bv.setBoard_content(rs.getString("board_content"));
			
				boardList.add(bv);
			}
			
		}catch(SQLException e) {
			e.printStackTrace();
		}finally {
			disConnect();
		}
		
		return boardList;
	}
	
	//작성자 검색
	@Override
	public List<BoardVO> getSearchWriter(String writer) {
		List<BoardVO> boardList = new ArrayList<BoardVO>();
		
		try {
			conn = DBUtil3.getConnection();
			String sql = "select board_no, board_title, board_writer, TO_CHAR(TO_DATE(board_date, 'YY.MM.DD'), 'YY.MM.DD') board_date, board_content from jdbc_board " 
						+ " where board_writer LIKE ? ";
			
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, writer);
			
			rs = pstmt.executeQuery();
						
			while(rs.next()) {
				BoardVO bv = new BoardVO();
				
				bv.setBoard_no(rs.getString("board_no"));
				bv.setBoard_title(rs.getString("board_title"));
				bv.setBoard_writer(rs.getString("board_writer"));
				bv.setBoard_date(rs.getString("board_date"));
				bv.setBoard_content(rs.getString("board_content"));
			
				boardList.add(bv);
			}
			
		}catch(SQLException e) {
			e.printStackTrace();
		}finally {
			disConnect();
		}
		
		return boardList;
	}

}
