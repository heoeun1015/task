package board.service;

import java.util.List;

import board.vo.BoardVO;

public interface IBoardService {

	public int insertBoard(BoardVO bv);
	

	public boolean getWriter(String boardWriter);
	

	public List<BoardVO> getAllBoardList();


	public int updateBoard(BoardVO bv);
	

	public List<BoardVO> updateList(String boardWriter);


	public int deleteBoard(String boardWriter, String num);


	public List<BoardVO> getSearchTitle(String title);
	
	
	public List<BoardVO> getSearchContent(String content);
	
	
	public List<BoardVO> getSearchWriter(String writer);
}
