package kr.or.ddit.Board.main;

import java.sql.Date;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;


import kr.or.ddit.Board.Service.BoardService;
import kr.or.ddit.Board.Service.BoardServiceImpl;
import kr.or.ddit.Board.vo.BoardVO;

public class BoardSystem {

	Scanner scan = new Scanner(System.in);
	BoardService boardService = BoardServiceImpl.getInstance();
	
	
	public static void main(String[] args) {
		System.out.println();
		System.out.println("=======================================================");
		System.out.println("///////////////// [게시판 관리 프로그램] /////////////////////");
		System.out.println("=======================================================");
		new BoardSystem().start();
	}
	
	public void start() {
		
		int menu = 99;
		do {
		try {
			System.out.println();
			System.out.println("\n\n\n");
			System.out.println("=======================================================");
			System.out.println("1. 전체 게시글 조회");
			System.out.println("2. 게시글 작성");
			System.out.println("3. 작성한 게시글 수정");
			System.out.println("4. 작성한 게시글 삭제");
			System.out.println("5. 게시글 검색");
			System.out.println("-1. 종료");
			System.out.println("=======================================================");
			System.out.print("메뉴 입력 ---> ");
			menu = Integer.parseInt(scan.nextLine());
			
			switch(menu) {
				case 1: totalBoard();		break;
				case 2: writePost();		break;
				case 3: updatePost();		break;
				case 4: deletePost();		break;
				case 5: searchPost();		break;
				case -1: end();				break;
			}
		}catch(Exception e) {
			System.out.println("올바른 값을 입력해주세요.");
		}
		}while(menu != -1);
	
	}
	
	
	public void totalBoard() {
		System.out.println();
		System.out.println("\n\n\n");
		System.out.println("≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡");
		System.out.println("                     [전체 게시글]");
		System.out.println("―――――――――――――――――――――――――――――――――――――――――――――――――――――――");
		
		List<BoardVO> boardList = new ArrayList<>();
		boardList = boardService.totalBoard();
		
		if(boardList.size() == 0) {
			System.out.println("등록된 게시글이 없습니다.");
			System.out.println("≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡");
			return;
		}
		
			System.out.printf("%5s\t %13s\t %8s\t %11s\n", "글번호", "글제목", "작성자", "작성날짜");
			System.out.println("―――――――――――――――――――――――――――――――――――――――――――――――――――――――");
			
			for(BoardVO bv : boardList) {
				int boardNum = bv.getBoardNum();
				String boardTitle = bv.getBoardTitle();
				String boardWriter = bv.getBoardWriter();
				Date boardDate = bv.getBoardDate();
				
				System.out.printf("%5d\t %10s\t %7s\t %10s\n", boardNum, boardTitle, boardWriter, boardDate);
			}
			System.out.println("≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡");
	}
	
	
	
	public void writePost() {
		System.out.println();
		System.out.println("\n\n\n");
		System.out.println("≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡");
		System.out.println("                     [게시글 작성]");
		System.out.println("―――――――――――――――――――――――――――――――――――――――――――――――――――――――");
		
		System.out.print("글 제목: ");
		String boardTitle = scan.nextLine();
		System.out.print("작성자: ");
		String boardWriter = scan.nextLine();
		System.out.println("글 내용: ");
		String boardContent = scan.nextLine();
		
		Date today = new Date(new java.util.Date().getTime());
		
		BoardVO bv = new BoardVO();
			bv.setBoardTitle(boardTitle);
			bv.setBoardWriter(boardWriter);
			bv.setBoardContent(boardContent);
			bv.setBoardDate(today);
		
		int cnt = boardService.writePost(bv);
		
			if(cnt > 0) {
				System.out.println();
				System.out.println("게시글 등록이 완료되었습니다.");
				System.out.println("―――――――――――――――――――――――――――――――――――――――――――――――――――――――");
			}else {
				System.out.println();
				System.out.println("게시글 등록에 실패했습니다.");
				System.out.println("―――――――――――――――――――――――――――――――――――――――――――――――――――――――");
			}
	}
	
	
	
	
	public void updatePost() {
		System.out.println();
		System.out.println("\n\n\n");
		System.out.println("≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡");
		System.out.println("                     [게시글 수정]");
		System.out.println("―――――――――――――――――――――――――――――――――――――――――――――――――――――――");
		
		boolean check = false;
		int boardNum = 0;
		
		while(check == false) {
			System.out.print("수정할 글의 게시번호를 입력해주세요. --> ");
			boardNum = Integer.parseInt(scan.nextLine());
			
			check = boardService.checkboardNumber(boardNum);
			if(check == false) { ifFalse();	}
		}
		
			System.out.println();
			System.out.println("[게시글을 수정합니다.]");
			System.out.print("글 제목: ");
			String boardTitle = scan.nextLine();
			System.out.print("작성자: ");
			String boardWriter = scan.nextLine();
			System.out.println("글 내용: ");
			String boardContent = scan.nextLine();

			BoardVO bv = new BoardVO();
				bv.setBoardTitle(boardTitle);
				bv.setBoardWriter(boardWriter);
				bv.setBoardContent(boardContent);
				bv.setBoardNum(boardNum);
			
			int cnt = boardService.updatePost(bv);
			
			if(cnt > 0) {
				System.out.println();
				System.out.println();
				System.out.println("게시글 수정이 완료되었습니다.");
				System.out.println("―――――――――――――――――――――――――――――――――――――――――――――――――――――――");
			}else {
				System.out.println("게시글 수정에 실패했습니다.");
				System.out.println("―――――――――――――――――――――――――――――――――――――――――――――――――――――――");
			}
	}
	
	
	
	public void deletePost() {
		System.out.println();
		System.out.println("\n\n\n");
		System.out.println("≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡");
		System.out.println("                     [게시글 삭제]");
		System.out.println("―――――――――――――――――――――――――――――――――――――――――――――――――――――――");
		
		boolean check = false;
		int boardNum = 0;

		while(check == false) {
			System.out.print("삭제할 글의 게시번호를 입력해주세요. --> ");
			boardNum = Integer.parseInt(scan.nextLine());
			
			check = boardService.checkboardNumber(boardNum);
				if(check == false) { ifFalse();	}
		}
		
		int cnt = boardService.deletePost(boardNum);
			if(cnt > 0) {
				System.out.println("게시글 삭제가 완료되었습니다.");
				System.out.println("―――――――――――――――――――――――――――――――――――――――――――――――――――――――");
			}else {
				System.out.println("게시글 삭제에 실패했습니다.");
				System.out.println("―――――――――――――――――――――――――――――――――――――――――――――――――――――――");
			}
	}	
	
	
	
	public void searchPost() {
		System.out.println();
		System.out.println("\n\n\n");
		System.out.println("≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡≡");
		System.out.println("                     [게시글 검색]");
		System.out.println("―――――――――――――――――――――――――――――――――――――――――――――――――――――――");
		
		int boardNum = 0;
		boolean check = false;
		do {
			System.out.print("찾으실 게시글의 글번호를 입력해주세요 >> ");
			boardNum = Integer.parseInt(scan.nextLine());
			
			check = boardService.checkboardNumber(boardNum);
			if(check == false) { ifFalse();	}
		}while(check == false);
	
	// -----------------------------------------------------------------
		
		List<BoardVO> boardList = new ArrayList<>();
		boardList = boardService.searchPost(boardNum);
		
		System.out.println();
		System.out.println("―――――――――――――――――――――――――――――――――――――――――――――――――――――――");
		System.out.printf("%5s\t %13s\t %8s\t %11s\n", "글번호", "글제목", "작성자", "작성날짜");
		System.out.println("―――――――――――――――――――――――――――――――――――――――――――――――――――――――");
		
		for(BoardVO bv : boardList) {
			String boardTitle = bv.getBoardTitle();
			String boardWriter = bv.getBoardWriter();
			Date boardDate = bv.getBoardDate();
			String boardContent = bv.getBoardContent();
			System.out.printf("%5d\t %10s\t %7s\t %10s\n", boardNum, boardTitle, boardWriter, boardDate);
			System.out.println("―――――――――――――――――――――――――――――――――――――――――――――――――――――――");
			System.out.println("[글 내용]");
			System.out.println(boardContent);
		}
	}
	
	
	public void end() {
		System.out.println();
		System.out.println("\n\n\n");
		System.out.println("프로그램을 종료합니다.");
		System.out.println("=======================================================");
		System.out.println("///////////////////////////////////////////////////////");
		System.out.println("=======================================================");
		
	}
	
	
	private void ifFalse() {
			System.out.println("입력하신 게시글이 존재하지 않습니다.");
			System.out.println("다시 입력해주세요.");
			System.out.println();
	}
	
	
}