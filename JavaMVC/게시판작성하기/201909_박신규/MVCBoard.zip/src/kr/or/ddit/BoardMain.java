package kr.or.ddit;
import java.sql.SQLException;
import java.util.List;
import java.util.Scanner;

import kr.or.ddit.board.service.IBoardService;
import kr.or.ddit.board.service.BoardServiceImpl;
import kr.or.ddit.board.vo.BoardVO;
import kr.or.ddit.util.DBUtil;

/*
	회원정보를 관리하는 프로그램을 작성하는데 
	아래의 메뉴를 모두 구현하시오. (CRUD기능 구현하기)
	(DB의 MYMEMBER테이블을 이용하여 작업한다.)

 * 자료 삭제는 회원ID를 입력 받아서 삭제한다.

	예시메뉴)
	----------------------
		== 작업 선택 ==
		1. 자료 입력			---> insert
		2. 자료 삭제			---> delete
		3. 자료 수정			---> update
		4. 전체 자료 출력	---> select
		5. 작업 끝.
	----------------------


// 회원관리 프로그램 테이블 생성 스크립트 
create table mymember(
    mem_id varchar2(8) not null,  -- 회원ID
    mem_name varchar2(100) not null, -- 이름
    mem_tel varchar2(50) not null, -- 전화번호
    mem_addr varchar2(128)    -- 주소
);

 */
public class BoardMain {

	// Service객체 변수를 선언한다.
	private IBoardService service;

	private Scanner scan = new Scanner(System.in);

	public BoardMain() {
		service = new BoardServiceImpl();
	}

	/**
	 * 메뉴를 출력하는 메서드
	 */
	public void displayMenu(){
		System.out.println();
		System.out.println("-----------------------------------------------");
		System.out.println("  === 작 업 선 택 ===");
		System.out.println("  1. 자료 입력");
		System.out.println("  2. 자료 삭제");
		System.out.println("  3. 자료 수정");
		System.out.println("  4. 전체 자료 출력");
		System.out.println("  5. 검색");
		System.out.println("  6. 작업 끝.");
		System.out.println("-----------------------------------------------");
		System.out.print("원하는 작업 선택 >> ");
	}

	/**
	 * 프로그램 시작메서드
	 */
	public void start(){
		int choice;
		do{
			displayMenu(); //메뉴 출력
			choice = scan.nextInt(); // 메뉴번호 입력받기
			switch(choice){
			case 1 :  // 자료 입력
				insertBoard();
				break;
			case 2 :  // 자료 삭제
				deleteBoard();
				break;
			case 3 :  // 자료 수정
				updateBoard();
				break;
			case 4 :  // 전체 자료 출력
				displayBoardAll();
				break;
			case 5 :  // 작업 끝
				searchBoard();
			case 6 :  // 작업 끝
				System.out.println("작업을 마칩니다.");
				break;
			default :
				System.out.println("번호를 잘못 입력했습니다. 다시입력하세요");
			}
		}while(choice!=5);
	}

	private void searchBoard() {
		System.out.println();
		System.out.print("검색할 게시판 번호를 입력해주세요 : ");
		int boardno = scan.nextInt();

		List<BoardVO> boardList = service.getAllSearchList(boardno);

		for(BoardVO mv : boardList) {
			System.out.println("-----------------------------------------------");
			System.out.println(mv.getBoard_no() + "\t" + mv.getBoard_title() + "\t" + mv.getBoard_writer() + "\t" + mv.getBoard_date() + "\t" + mv.getBoard_contents());
			System.out.println("-----------------------------------------------");
		}
		
		System.out.println("출력작업 끝.....");
	}

	private void deleteBoard() {
		System.out.println();
		System.out.print("삭제할 게시판 번호를 입력하세요.");
		int boardno = scan.nextInt();

		int cnt = service.deleteBoard(boardno);

		if(cnt>0){
			System.out.println(boardno + "회원 삭제 성공");
		} else {
			System.out.println(boardno + "회원 삭제 실패");
		}
	}

	private void updateBoard() {
		System.out.println();
		//String memId = "";
		int boardno;
		boolean chk = true;

		do {
			System.out.println("수정할 회원ID를 입력하세요 >> ");
			boardno = scan.nextInt();

			chk = service.getBoard(boardno);
			if(chk == false) {
				System.out.println(boardno + "회원은 없는 회원입니다.");
				System.out.println("수정할 자료가 없으니 다시 입력하세요.");
			}

		} while(chk == false);

		System.out.println("수정할 내용을 입력하세요.");
		System.out.println("새로운 제목 >>");
		String memName = scan.next();

		System.out.println("새로운 작성자 >> ");
		String memTel = scan.next();

		scan.nextLine();
		System.out.println("새로운 내용 >> ");
		String memAddr = scan.nextLine();

		BoardVO mv = new BoardVO();
		mv.setBoard_no(boardno);
		mv.setBoard_title(memName);
		mv.setBoard_writer(memTel);
		mv.setBoard_contents(memAddr);
		int cnt = service.updateBoard(mv);

		if(cnt > 0) {
			System.out.println(boardno + " 게시판의 정보를 수정했습니다.");
		}else {
			System.out.println(boardno + " 게시판의 정보 수정 실패.");
		}
	}

	/**
	 * 전체 회원을 출력하는 메서드
	 */
	private void displayBoardAll() {
		System.out.println();
		System.out.println("-----------------------------------------------");
		System.out.println(" ID\t이름\t전화번호\t\t주 소");
		System.out.println("-----------------------------------------------");

		List<BoardVO> boardList = service.getAllBoardList();

		for(BoardVO mv : boardList) {
			System.out.println(mv.getBoard_no() + "\t" + mv.getBoard_title() + "\t" + mv.getBoard_writer() + "\t" + mv.getBoard_date() + "\t" + mv.getBoard_contents());
		}
		System.out.println("-----------------------------------------------");
		System.out.println("출력작업 끝.....");
	}

	/**
	 * 회원을 추가하는 메서드
	 */
	private void insertBoard() {

		System.out.println();
		System.out.print("-제목을 입력하세요 : ");
		String title = scan.next();

		System.out.print("-작성자를 입력하세요 : ");
		String writer = scan.next();

		System.out.print("-내용을 입력하세요 : ");
		String contents = scan.next();

		scan.nextLine(); // 입력 버퍼 비우기

		BoardVO mv = new BoardVO();
		mv.setBoard_title(title);
		mv.setBoard_writer(writer);
		mv.setBoard_contents(contents);
		
		int cnt = service.insertBoard(mv);

		if(cnt > 0) {
			System.out.println("게시판 등록 성공");
		} else {
			System.out.println("게시판 등록 실패");
		}
		
	}

	public static void main(String[] args) {
		BoardMain memObj = new BoardMain();
		memObj.start();
	}
}
