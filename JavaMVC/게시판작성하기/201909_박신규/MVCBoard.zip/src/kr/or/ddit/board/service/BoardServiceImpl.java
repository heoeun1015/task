package kr.or.ddit.board.service;

import java.util.List;

import kr.or.ddit.board.dao.BoardDaoImpl;
import kr.or.ddit.board.vo.BoardVO;

public class BoardServiceImpl implements IBoardService {
	
	// 사용할 DAO의 객체변수를 선언한다.
	private BoardDaoImpl boDao;
	public BoardServiceImpl() {
		boDao = new BoardDaoImpl();
	}

	@Override
	public int insertBoard(BoardVO mv) {
		return boDao.insertBoard(mv);
	}

	@Override
	public boolean getBoard(int memId) {
		return boDao.getBoard(memId);
	}

	@Override
	public List<BoardVO> getAllBoardList() {
		return boDao.getAllBoardList();
	}
	
	@Override
	public List<BoardVO> getAllSearchList(int memId) {
		return boDao.getAllSearchList(memId);
	}

	@Override
	public int updateBoard(BoardVO mv) {
		return boDao.updateBoard(mv);
	}

	@Override
	public int deleteBoard(int memId) {
		return boDao.deleteBoard(memId);
	}
	
	@Override
	public List<BoardVO> getSearchMember(BoardVO mv) {
		return boDao.getSearchMember(mv);
	}
}