package kr.or.ddit.board.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import kr.or.ddit.board.vo.BoardVO;
import kr.or.ddit.util.DBUtil;
import kr.or.ddit.util.DBUtil3;

public class BoardDaoImpl implements IBoardDao {
	private Connection conn;
	private Statement stmt;
	private PreparedStatement pstmt;
	private ResultSet rs;
	
	/**
	 * 자원반납
	 */
	private void disConnect() {
		// 종료(사용했던 자원을 모두 반납한다.)
		//scan.close();
		if(pstmt != null) try {pstmt.close();} catch(SQLException e) {}
		if(stmt != null) try {stmt.close();} catch(SQLException e) {}
		if(conn != null) try {conn.close();} catch(SQLException e) {}
		if(rs != null) try {rs.close();} catch(SQLException e) {}
	}

	@Override
	public int insertBoard(BoardVO mv) {
		///////////////////////////
		int cnt = 0;
		try {
			//conn = DBUtil.getConnection();
			conn = DBUtil3.getConnection();

			//String sql = "insert into mymember " + "(mem_id, mem_name, mem_tel, mem_addr) " + " values (?,?,?,?) ";
			String sql = "insert into mvc_board values (seq_board.nextval,?,?,sysdate,?)";

			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, mv.getBoard_title());
			pstmt.setString(2, mv.getBoard_writer());
			pstmt.setString(3, mv.getBoard_contents());

			cnt = pstmt.executeUpdate();
			
		} catch(SQLException e) {
			e.printStackTrace();
		} finally {
			disConnect();
		}
		//////////////////////////
		
		return cnt;
	}

	@Override
	public boolean getBoard(int memId) {
		boolean chk = false;
		try {
			conn = DBUtil.getConnection();
			String sql = "select count(*) cnt from mvc_board where mem_id = ? ";

			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, memId);

			rs = pstmt.executeQuery();

			int cnt = 0;
			if(rs.next()) {
				cnt = rs.getInt("cnt");
			}
			if(cnt > 0) {
				chk = true;
			}
		} catch(SQLException e) {
			e.printStackTrace();
		} finally {
			disConnect();
		}
		return chk;
	}

	@Override
	public List<BoardVO> getAllBoardList() {
		
		List<BoardVO> memList = new ArrayList<BoardVO>();
		
		try {
			conn = DBUtil.getConnection();

			String sql = "select * from mvc_board";

			stmt = conn.createStatement();

			rs = stmt.executeQuery(sql);

			while(rs.next()) {
				BoardVO mv = new BoardVO();
				mv.setBoard_no(rs.getInt("board_no"));
				
				mv.setBoard_title(rs.getString("board_title"));
				mv.setBoard_writer(rs.getString("board_writer"));
				mv.setBoard_contents(rs.getString("board_content"));
				
				mv.setBoard_date(rs.getString("board_date"));
				
				memList.add(mv);
			}

		} catch(SQLException e){
			e.printStackTrace();
		} finally {
			disConnect();
		}
		
		return memList;
	}
	
	@Override
	public List<BoardVO> getAllSearchList(int boardno) {
		
		List<BoardVO> memList = new ArrayList<BoardVO>();
		
		try {
			conn = DBUtil.getConnection();

			String sql = "select * from mvc_board where board_no = " + boardno;

			stmt = conn.createStatement();

			rs = stmt.executeQuery(sql);

			while(rs.next()) {
				BoardVO mv = new BoardVO();
				mv.setBoard_no(rs.getInt("board_no"));
				mv.setBoard_title(rs.getString("board_title"));
				mv.setBoard_writer(rs.getString("board_writer"));
				mv.setBoard_contents(rs.getString("board_content"));
				mv.setBoard_date(rs.getString("board_date"));
				
				memList.add(mv);
			}

		} catch(SQLException e){
			e.printStackTrace();
		} finally {
			disConnect();
		}
		
		return memList;
	}

	@Override
	public int updateBoard(BoardVO mv) {
		int cnt = 0;
		try {
			conn = DBUtil.getConnection();

			String sql = "update mvc_board set mem_name = ?, mem_tel = ?, mem_addr = ? where mem_id = ? ";

			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, mv.getBoard_title());
			pstmt.setString(2, mv.getBoard_writer());
			pstmt.setString(3, mv.getBoard_contents());
			pstmt.setInt(4, mv.getBoard_no());

			cnt = pstmt.executeUpdate();
			
		} catch(SQLException e) {
			e.printStackTrace();
		} finally {
			disConnect();
		}
		return cnt;
	}

	@Override
	public int deleteBoard(int boardno) {
		int cnt = 0;
		try {
			conn = DBUtil.getConnection();
			String sql = "delete from mvc_board where board_no = ?";

			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, boardno);

			cnt = pstmt.executeUpdate();
		} catch(SQLException e) {
			e.printStackTrace();
		} finally {
			disConnect();
		}
		return cnt;
	}
	

	@Override
	public List<BoardVO> getSearchMember(BoardVO mv) {
		// TODO Auto-generated method stub
		return null;
	}
}