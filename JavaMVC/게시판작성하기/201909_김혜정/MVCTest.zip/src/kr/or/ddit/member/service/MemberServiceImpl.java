package kr.or.ddit.member.service;

import java.util.List;

import kr.or.ddit.member.dao.IMemberDao;
import kr.or.ddit.member.dao.MemberDaoImpl;
import kr.or.ddit.member.vo.MemberVO;

public class MemberServiceImpl implements IMemberService {
//이 test에서는 dao에게 기능호출하는 기능뿐이다.
	
	//사용할 DAO의 객체변수를 선언한다.
	private IMemberDao memDao;
	
	public MemberServiceImpl() { //생성자
		memDao = new MemberDaoImpl();
	}
	
	@Override
	public int insertMember(MemberVO mv) {
		
	/*	예를들면 이처럼 여러기능을 넣을 수 있다. commit,rollback처리도 한다.
	 	int cnt = memDao.insertMember(mv);
		if(cnt>0) {
			//메일전송객체.sendMail(mv.getMem_id());
		}
		return cnt;*/
		
		return memDao.insertMember(mv);
	}

	@Override
	public boolean getMember(String memId) {
		return memDao.getMember(memId);
	}

	@Override
	public List<MemberVO> getAllMemberList() {
		return memDao.getAllMemberList();
	}

	@Override
	public int updateMember(MemberVO mv) {
		return memDao.updateMember(mv);
	}

	@Override
	public int deleteMember(String memId) {
		return memDao.deleteMember(memId);
	}

	@Override
	public List<MemberVO> getSearchMember(MemberVO mv) {
		return memDao.getSearchMember(mv);
	}

}
